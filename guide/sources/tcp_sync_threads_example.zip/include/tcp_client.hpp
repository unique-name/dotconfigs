/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class tcp client. Used by H3
| manager in order to connect to H3 manager client and sys manager server.
|
************************************************************************/

#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <h3_defines.hpp>
#include <syslog.h>

using boost::asio::ip::tcp;

class tcp_client {
      public:
	tcp_client(const char *hostname, const unsigned int &port, boost::asio::io_service &ios);
	void send_msg(const char *msg, size_t len);
	connection_status get_status() const { return status; }
	char* sync_read(const boost::system::error_code &error);
	void sync_connect(boost::asio::io_service &ios);

      private:
	tcp::socket *socket_ptr;
	tcp::endpoint endpoint;
	connection_status status;
	char data[BUF_LEN];
};
#endif

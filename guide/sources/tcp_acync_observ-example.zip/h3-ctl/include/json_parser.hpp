/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class jason parser and other
| definitions that used by config manager in order to parse setup file.
|
************************************************************************/

#ifndef JSON_PARSER_H
#define JSON_PARSER_H

#include <json/value.h>
#include <json/reader.h>
#include <common_structs.hpp>
#include <h3_defines.hpp>
#include <syslog.h>

enum class parse_res {
	PARS_FAIL,
	PARS_SUCC,
	PARS_NOT_ACT,
};

class json_parser {
      private:
	Json::Value json_obj;
	int board_slots_num;

      public:
	json_parser();

	common_err load_json_file(const char *filename);
	parse_res parse_cfg_data(struct general_hw &cfg_general_hw);
	parse_res parse_cfg_data(struct board &cfg_board, int board_num);
	parse_res parse_cfg_data(struct device_port &cfg_device_port, int board_num, int port_num);
	int get_slots_number() const { return board_slots_num; }
	int get_board_ports_num(int board_num) const;
};

#endif

/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class H3 manager and other
| definitions used by class.
|
************************************************************************/

#ifndef H3_CONTROL_H
#define H3_CONTROL_H

#include <boost/thread.hpp>
#include <json_parser.hpp>
#include <h3_defines.hpp>
#include <fstream>
#include <glv-defines.h>
#include <observer.hpp>
#include <sending_queue.hpp>
#include <tcp_client.hpp>
#include <syslog.h>

using thread_p = std::unique_ptr<boost::thread>;

class h3_control {
      public:
	h3_control(const std::string &ip = "127.0.0.1");
	h3_control &operator=(const h3_control &) = delete;
	h3_control(const h3_control &) = delete;
	~h3_control();

      private:
	std::string sys_ip;
	common_err global_err;
	mode global_work_mode;
	boost::asio::io_service ios;
	observer<tcp_client, signature> tcp_observ;
	tcp_client *soc_client;
	json_parser j_parser;
	thread_p tcp_service_thread;
	sending_queue tx_queue_to_sys;
	execution exec_result;
	std::map<std::string, Glv_DCType> board_type;
	std::map<std::string, Glv_BaudRate> baudrate;
	std::map<std::string, Glv_PortConfSrc> host_src;

	void init_tcp_callback();
	void connect_to_sys_server();
	void run_threads();
	void message_sender();
	void periodic_work();
	void init_conversion_maps();
	void read_saved_board_data();
	void save_board_data();

	void load_json_file(const char *filename);
	void parse_and_config_boards();
	void parse_and_config_ports();

	void send_message_to_sys(const void *msg, size_t size);
	void sys_message_handler(const char *msg);
	void send_finish_exec_to_sys(const command which_comm);
	void error_report_to_sys(const int id[4], const char *uniq_id);

	void config_system();
	void main_config(struct general_hw hw);
	void board_config(struct board slot_board);
	void port_config(struct device_port port);
	void set_time_to_boards(const time_t curr_time);
	void check_FPD_ports_tx();
	void start_handler();
	void stop_handler();
};

#endif

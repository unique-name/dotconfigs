/************************************************************************
| Copyright (c) OSR Enterprises AG, 2017.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: Protocol definition for communicating between the
|	       'system control', 'config manager', and 'H3 manager'.
|
************************************************************************/

#ifndef COMMON_STR_H
#define COMMON_STR_H

#include <time.h>

// size of buffer used in tcp sockets
constexpr int BUF_LEN = 1024 * 2;
constexpr int ID_LEN = 40;
constexpr int FILENAME_SIZE = 120;

typedef enum connection_status {
	CONNECTED,
	DISCONNECTED
} connection_status;

// list of errors that may occure
enum class common_err
{
	ERR_NONE,	  // no errors
	ERR_JSON_FILE,    // problem with json file path/name
	ERR_JSON_CONTENT, // problem with parsing of json content
	ERR_HW_VERSION,	  // problem with HW version compatibility
	ERR_SW_VERSION,	  // problem with SW version compatibility
	ERR_FILE_ACCESS,  // problem with access to file in file system
	ERR_H3_MAIN,	  // failed config of H3 mainboard
	ERR_BOARD_EXIST,  // daughterboard does not exist
	ERR_BOARD_PWR_UP, // failed to power up daughterboard
	ERR_BOARD_TYPE,	  // daughterboard type mismatch with configuration
	ERR_BOARD_CONFIG, // failed configuration of daughterboard
	ERR_PORT_CONFIG,  // failed configuration of port of one's daughterboard
	ERR_PORT_TX,	  // port does not transmit data
};

// result of command execution
typedef enum result {
	RES_SUCCESS = 0,
	RES_FAIL,
} result;

// system work mode
typedef enum mode {
	MODE_RECORD = 0,
	MODE_PLAYBACK,
} mode;

// commands between system and configure managers
enum class command
{
	STATUS,		 // !!! currently not implemented
	FINISH_EXEC,     // report after command execution with result
	ERROR_REPORT,    // report in case error occured
	SET_MODE,	 // setting work mode for system
	GET_MODE,	 // obtain work mode from H3
	LOAD_JSON,       // load json fie for parsing
	CONFIG_SYSTEM,   // system configuration sequence
	START,		 // start work
	STOP,		 // finish work
	NUM_COMMANDS,	 // It is not a command. Used to get number of enums
};

// general message type for communication
template <typename T> struct message {
	command comm_type;
	T params;
};

#if 0
// struct for status data
struct status {
	int id[4];
	result status;
};
#endif

struct finish_exec {
	command which_command;
	result res;
};

struct err_report {
	common_err error;
	int id[4];
	char uniq_id[ID_LEN];
};

struct work_mode {
	mode w_mode;
};

struct json {
	char path_to_file[FILENAME_SIZE];
};

struct timestamp {
	struct tm timeinfo;
};

#if 0
// feature for GPS data
struct location {
	float latitude;
	float longtitude;
};
#endif 

#endif

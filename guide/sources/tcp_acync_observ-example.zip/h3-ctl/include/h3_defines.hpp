/************************************************************************
| Copyright (c) OSR Enterprises AG, 2017.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains common message types, message data structs
| and other defines for communication between config manager and H3
| manager.
|
************************************************************************/

#ifndef COMMON_H3_H
#define COMMON_H3_H

#include <common_structs.hpp>
#include <cstring>
#include <stdbool.h>
#include <time.h>
#include <array>

using signature = void(const char *);
constexpr const char* SYS_SERVER_PORT = "6600";
constexpr size_t STR_LEN = 40;
constexpr int PORTS_NUM = 20;	// max number of ports on board

// should stay as common enum not class
typedef enum p_type {
	NONE = 0,
	FPD,
	ETH,
	CAN,
	GPS,
	USB,
} p_type;

// data that stored in board config file
typedef struct recorded_board_data {
	mode last_work_mode;
	unsigned int pps_mode;
} recorded_board_data;

enum class unit_status {
	NOT_USED,
	DEAD,
	LIVE,
};

// contains ports information inside board
typedef struct h3_port_status {
	bool is_in_use;
	int port_direction;
	p_type port_type;
	int stream_id;
	char uniq_id[STR_LEN];
	unit_status port_st;
} h3_port_status;

// contains board information and array of ports/devices
typedef struct h3_board_status {
	int global_ind;
	unit_status board_st;
	unsigned char mac[6] = {0};
	std::array<h3_port_status, PORTS_NUM> ports;
} h3_board_status;

typedef enum execution {
	SUCCESS = 0,
	FAIL,
	NO_RESULT,
} execution;

struct general_hw {
	char name[STR_LEN];
	char serial_number[STR_LEN];
	int hw_version[4];
	int sw_version[4];
};

struct board {
	int slot_index;
	char board_type[STR_LEN];
	int hw_version[4];
	int fpga_version[4];
};

struct device_port {
	int id[4];
	char uniq_id[STR_LEN];
	// the folloving fields may be 0, depend on device type
	int custom_cam_hfov;
	int custom_cam_res_horz;
	int custom_cam_res_vert;
	int custom_cam_fps;
	char custom_cam_host[STR_LEN];
	char custom_cam_format[STR_LEN];
	char custom_can_head_br[STR_LEN];
	char custom_can_data_br[STR_LEN];
};

struct gps_location {
	float latitude;
	float longitude;
};

#endif

/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of udp synchronous server.
|
************************************************************************/

#include <udp_server.h>
#include <iostream>

udp_server::udp_server(boost::asio::io_service& io_service)
	    : ios(io_service), remote_p(udp::v4(), REMOTE_CL_PORT),
	    cyber_p(udp::v4(), CYBER_CL_PORT), cyber_soc(io_service, cyber_p),
	    remote_soc(io_service, remote_p)
{
	sock_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	if (sock_fd < 0)
		std::cout << "Can't create raw socket" << std::endl;

	if (-1 == setsockopt(sock_fd, SOL_SOCKET, SO_BINDTODEVICE, sock_iface,
			     sizeof(sock_iface))) {
		std::cout << "Can't set options for socket: " << sock_iface << std::endl;
		std::cout << "Try to run it with sudo" << std::endl;
	}

	bind(sock_fd, 0, 0);
}

char * udp_server::receive_from_cyber()
{
	std::memset(cyber_data, 0, BUFF_LEN);
	cyber_soc.receive_from(boost::asio::buffer(cyber_data, BUFF_LEN), cyber_p);
	return cyber_data;
}

char * udp_server::receive_from_remote()
{
	std::memset(remote_data, 0, BUFF_LEN);
	remote_soc.receive_from(boost::asio::buffer(remote_data, BUFF_LEN), remote_p);
	return remote_data;
}

char * udp_server::receive_from_pcie()
{
	std::memset(pcie_data, 0, BUFF_LEN);
	read(sock_fd, pcie_data, BUFF_LEN);
	return pcie_data;
}

void udp_server::send_to_cyber(const char *data, size_t size)
{
	cyber_soc.send_to(boost::asio::buffer(data, size), cyber_p);
}

void udp_server::send_to_remote(const char *data, size_t size)
{
	remote_soc.send_to(boost::asio::buffer(data, size), remote_p);
}

void udp_server::send_to_pcie(const char *data, size_t size)
{
	send(sock_fd, data, size, 0);
	//write(sock_fd, data, size);
}

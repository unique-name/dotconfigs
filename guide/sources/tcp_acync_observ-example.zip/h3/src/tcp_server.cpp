/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of class tcp server.
|
************************************************************************/

#include <boost/bind.hpp>
#include <iostream>
#include <tcp_server.hpp>

using boost::asio::ip::tcp;

tcp_server::tcp_server(boost::asio::io_service &ios_, short port)
    : ios(ios_), acceptor_(ios, tcp::endpoint(tcp::v4(), port))
{
	status = DISCONNECTED;
}

void tcp_server::accept_client()
{
	//tcp_session *new_session = new tcp_session(ios);
	session_ = std::unique_ptr<tcp_session>(new tcp_session(ios));
	acceptor_.async_accept(session_->get_socket(), boost::bind(&tcp_server::handle_accept, this,
			boost::asio::placeholders::error));
}

void tcp_server::handle_accept(const boost::system::error_code &error)
{
	if (!error) {
		register_notifier(*session_, [this](const char *msg) {
			notify(msg);

			if (!std::strcmp(msg, "disconnected")) {
				status = DISCONNECTED;
				accept_client();
			}
		});

		syslog(LOG_NOTICE, "Client connected");
		std::cout << "Client connected" << std::endl;
		// notify("connected");
		session_->start();
		status = CONNECTED;
	}
}

void tcp_server::send_msg(const char *msg, size_t len)
{
	session_.get()->send_msg(msg, len);
}

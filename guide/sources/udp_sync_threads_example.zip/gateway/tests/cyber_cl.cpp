/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: tester for CAN Eth gateway project.
|
************************************************************************/

#include <gateway_controller.h>
#include <udp_client.h>
#include <iostream>
#include <thread>

// canfd struct for low level data transfer
struct canfd {
	uint32_t   can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	uint8_t    len;     /* frame payload length in byte (0 .. 64) */
	uint8_t    flags;   /* additional flags for CAN FD */
	uint8_t    __res0;  /* reserved / padding */
	uint8_t    __res1;  /* reserved / padding */
	uint8_t    data[64] __attribute__((aligned(8)));
};

// osr data unit for transferring over network
struct custom_canfd {
	uint8_t osr_hdr[32];
	struct canfd cfd;
};

int main(int argc, char *argv[])
{
	boost::asio::io_service ios;

	std::cout << "Started " << argc << std::endl;

	if (argc < 2) {
		std::cout << "You need to provide IP address of Gateway" << std::endl;
		exit(1);
	}

	std::string ip = argv[1];
	udp_client client(ios, ip, (int)CYBER_CL_PORT);

	std::thread receiver([&client](){
		while (true) {
			void * data_p;
			struct custom_canfd *message;

			data_p = client.receive_from_server();	
			std::cout << "CYBER: Received message: " << (char *)data_p << std::endl;
			message = (struct custom_canfd *)data_p;
			std::cout << "Printing CAN message: id: " << message->cfd.can_id <<
			std::hex << " len: " << static_cast<int>(message->cfd.len) << " data: " <<
			static_cast<int>(message->cfd.data[0]) <<
			static_cast<int>(message->cfd.data[1]) <<
			static_cast<int>(message->cfd.data[2]) <<
			static_cast<int>(message->cfd.data[3]) << std::endl;
		}
	});

	std::string message = "hello";
	client.send_to_server(message.c_str(), message.size());

	int counter = 0;

	while (true) {
		std::cout << "Press enter to send message" << std::endl;
		counter++;
		getchar();

		struct custom_canfd message;
		std::memset(&message, 0, sizeof(message));

		// filling dummy data package for transfer test
		message.cfd.can_id = 1;
		message.cfd.len = 8;
		message.cfd.data[0] = counter;
		message.cfd.data[1] = 0xab;
		message.cfd.data[2] = 0xcd;
		message.cfd.data[3] = 0xef;

		client.send_to_server((char *)&message, sizeof(message));
	}

	receiver.join();
	return 0;
}

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/can/dev.h>
#include <linux/inet.h>

#define CAN_DRV_NAME "dnv_can"
#define OSR_HEADER_SIZE 32
#define GATEWAY_PORT 6502

static char *ip;
module_param(ip, charp, 0000);
static bool gw_connected = false;
static struct platform_device *dnv_can_device;

static int dnv_probe(struct platform_device *pdev);
static int dnv_remove(struct platform_device *pdev);

static struct platform_driver dnv_can_driver = {
	.driver = {
		.name = CAN_DRV_NAME,
		.owner = THIS_MODULE,
	},
	.probe = dnv_probe,
	.remove = dnv_remove,
};

struct priv_data {
	struct can_priv can;
	struct net_device *ndev;
	struct napi_struct napi;
	struct socket *sock;
	uint32_t gateway_ip;
	struct task_struct *hs_thread_id;
};

struct osr_canfd_tx {
	u8 osr_hdr[OSR_HEADER_SIZE];
	struct canfd_frame cfd;
};

static netdev_tx_t canfd_xmit(struct sk_buff *skb, struct net_device *ndev) {
	struct priv_data *priv = netdev_priv(ndev);
	struct canfd_frame *canfd = (struct canfd_frame *)skb->data;
	struct osr_canfd_tx can_tx;
	struct kvec vec;
	struct msghdr msg;
	struct sockaddr_in daddr;
	
	pr_debug("called %s\n", __func__);

	if (can_dropped_invalid_skb(ndev, skb)) {
		pr_emerg("Error: not valid can frame\n");
		skb_tx_error(skb);
		dev_kfree_skb(skb);
		return -EBADMSG;
	}

	if (false == gw_connected) {
		skb_tx_error(skb);
		dev_kfree_skb(skb);
		return -ENETDOWN;
	}

	memcpy(&can_tx.cfd, canfd, sizeof(struct canfd_frame));
	memset(&daddr, 0, sizeof(daddr));
	memset(&msg, 0, sizeof(msg));
	daddr.sin_family = AF_INET;
	daddr.sin_port = htons(GATEWAY_PORT);
	daddr.sin_addr.s_addr = priv->gateway_ip; 
	
	msg.msg_name = &daddr;
	msg.msg_namelen = sizeof(struct sockaddr_in);
	vec.iov_base = &can_tx;
	vec.iov_len = sizeof(can_tx);

	kernel_sendmsg(priv->sock, &msg, &vec, 1, sizeof(can_tx));
	return NETDEV_TX_OK;
}

void report_gw_conn(void)
{
	gw_connected = true;
	pr_info("Gateway replied to handshake\n");
}
EXPORT_SYMBOL(report_gw_conn);

static const struct net_device_ops canfd_ops = {
    //.ndo_open = rcar_can_open,
    //.ndo_stop = rcar_can_close,
    .ndo_start_xmit = canfd_xmit,
    //.ndo_change_mtu = can_change_mtu,
};

static int net_handshake(void *priv)
{
	struct kvec vec;
	struct msghdr msg;
	struct sockaddr_in daddr;
	char message[6];

	memset(&daddr, 0, sizeof(daddr));
	memset(&msg, 0, sizeof(msg));
	daddr.sin_family = AF_INET;
	daddr.sin_port = htons(GATEWAY_PORT);
	daddr.sin_addr.s_addr = ((struct priv_data *)priv)->gateway_ip;

	msg.msg_name = &daddr;
	msg.msg_namelen = sizeof(struct sockaddr_in);
	strcpy(message, "hello");
	vec.iov_base = message;
	vec.iov_len = strlen(message) + 1;

	while(!kthread_should_stop()) {
		msleep(500);

		if (gw_connected)
			break;

		pr_debug("Denverton: sending handshake message to Gateway\n");
		kernel_sendmsg(((struct priv_data *)priv)->sock, &msg, &vec, 1,
				strlen(message) + 1);
	}

	((struct priv_data *)priv)->hs_thread_id = NULL;
	pr_info("Denverton: finished handshake\n");
	do_exit(0);
}

static int dnv_probe(struct platform_device *pdev) {
	struct net_device *ndev;
	struct priv_data *priv;
	int err;
	
	ndev = alloc_candev(sizeof(struct priv_data), 0);

	if (!ndev) {
		pr_emerg("Failed to allocate CAN network device\n");
		return -ENODEV;
	}
	
	priv = netdev_priv(ndev);
	priv->hs_thread_id = NULL;
	priv->gateway_ip = in_aton(ip);
	//pr_debug("Converted IP: 0x%08x\n", priv->gateway_ip);

	if (priv->gateway_ip == 0) {
		pr_emerg("Error: Denverton driver received bad IP as module parameter\n");
		free_candev(ndev);
		return -EINVAL;
	}

	priv->ndev = ndev;
	ndev->netdev_ops = &canfd_ops;
	//ndev->flags |= (IFF_UP | IFF_RUNNING);
	ndev->irq = -1;
	platform_set_drvdata(pdev, ndev);
	SET_NETDEV_DEV(ndev, &pdev->dev);
	netif_napi_add(ndev, &priv->napi, NULL, 4);
	err = register_candev(ndev);

	if (err) {
		pr_emerg("Falied to register CAN network device\n");
		netif_napi_del(&priv->napi);
		free_candev(ndev);
		return err;
	}

	can_set_static_ctrlmode(ndev, CAN_CTRLMODE_FD);
	err = sock_create(PF_INET, SOCK_DGRAM, IPPROTO_UDP, &priv->sock);

	if (err) {
		pr_emerg("Failed to create a UDP socket\n");
		unregister_candev(ndev);
		netif_napi_del(&priv->napi);
		free_candev(ndev);
		return err;
	}

	priv->hs_thread_id = kthread_run(net_handshake, priv, "handshake thread");

	if(IS_ERR(priv->hs_thread_id))  {
		pr_emerg("Failed to create a kernel thread\n");
		unregister_candev(ndev);
		netif_napi_del(&priv->napi);
		free_candev(ndev);
		return -EFAULT;
	}

	return 0;
}

static int dnv_remove(struct platform_device *pdev) {
	struct net_device *ndev = platform_get_drvdata(pdev);
	struct priv_data *priv = netdev_priv(ndev);
	
	if (priv->hs_thread_id)
		kthread_stop(priv->hs_thread_id);

	sock_release(priv->sock);
	unregister_candev(ndev);
	netif_napi_del(&priv->napi);
	free_candev(ndev);
	return 0;
}

static int __init dnv_init(void) {
	int retval;
	
	pr_info("Denverton CAN driver INIT\n");
	pr_debug("Denverton received param: %s\n", ip);

	if (!ip || (strlen(ip) == 0) || (ip[0] < '0') || (ip[0] > '9')) {
		pr_emerg("Error: Denverton driver bad/no parameter\n");
		return -EINVAL;
	}

	dnv_can_device = platform_device_alloc(CAN_DRV_NAME, -1);

	if (!dnv_can_device)
		return -ENOMEM;
	
	retval = platform_device_add(dnv_can_device);

	if (retval < 0) {
		platform_device_put(dnv_can_device);
		pr_emerg("Failed to create CAN platform device\n");
		return retval;
	}
	
	retval = platform_driver_probe(&dnv_can_driver, dnv_probe);

	if (retval < 0) {
		platform_device_unregister(dnv_can_device);
		pr_emerg("Failed to call CAN driver probe\n");
		return retval;
	}
	      
	return 0;
}

static void __exit dnv_exit(void) {
	platform_device_unregister(dnv_can_device);
	platform_driver_unregister(&dnv_can_driver);
	pr_info("Denverton CAN driver EXIT\n");
}

module_init(dnv_init);
module_exit(dnv_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Custom CAN driver module for Denverton");
MODULE_AUTHOR("Sergey Buloshnikov - OSR");

/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of H3 manager message handlers.
|
************************************************************************/

#include <h3_control.hpp>
#include <iostream>

// accumulates status of all boards and devices
h3_board_status boards_status_arr[7];

constexpr inline int conv_index_arr(int index)
{
	if (index < 7)
		return index - 1;
	else
		// for board 15
		return 6;
}

static int find_free_port_index(int board_index)
{
	int size = boards_status_arr[board_index].ports.size();
	int ind;

	for (ind = 0; ind < size; ++ind) {
		if (false == boards_status_arr[board_index].ports.at(ind).is_in_use) {
			boards_status_arr[board_index].ports.at(ind).is_in_use = true;
			break;
		}
	}

	(ind == size) ? (ind = -1) : (ind);
	return ind;
}

static unit_status compare_input_device(int board_index, h3_port_status port)
{
	unit_status retval = unit_status::NOT_USED;

	for (auto p : boards_status_arr[board_index].ports) {
		if (p.is_in_use && p.port_direction == 0)
			if (p.port_type == port.port_type && p.stream_id == port.stream_id)
				retval = p.port_st;
	}

	return retval;
}

void h3_control::load_json_file(const char *filename)
{
	exec_result = SUCCESS;
	global_err = j_parser.load_json_file(filename);

	if (common_err::ERR_JSON_FILE == global_err)
		syslog(LOG_NOTICE, "Failed to load json file");

	if (common_err::ERR_JSON_CONTENT == global_err)
		syslog(LOG_NOTICE, "Error in json content or version");

	if (common_err::ERR_NONE != global_err) {
		error_report_to_sys(0, NULL);
		exec_result = FAIL;
	}

	send_finish_exec_to_sys(command::LOAD_JSON);
}

void h3_control::config_system()
{
	syslog(LOG_NOTICE, "Starting configuration");
	struct general_hw cfg_general_hw;
	parse_res result;

	try {
		result = j_parser.parse_cfg_data(cfg_general_hw);
	}
	catch (Json::Exception const& ex) {
		ex.what();
		result = parse_res::PARS_FAIL;
	}

	if (parse_res::PARS_FAIL == result) {
		global_err = common_err::ERR_JSON_CONTENT;
		error_report_to_sys(0, NULL);
		exec_result = FAIL;
		send_finish_exec_to_sys(command::CONFIG_SYSTEM);
		return;
	}

	main_config(cfg_general_hw);

	if (FAIL == exec_result) {
		global_err = common_err::ERR_H3_MAIN;
		error_report_to_sys(0, NULL);
		exec_result = FAIL;
		send_finish_exec_to_sys(command::CONFIG_SYSTEM);
		return;
	}

	syslog(LOG_NOTICE, "Mainboard configured");
	std::cout << "Mainboard configured" << std::endl;
	exec_result = NO_RESULT;

	parse_and_config_boards();

	if (SUCCESS != exec_result) {
		// after json parsing fail can't continue
		send_finish_exec_to_sys(command::CONFIG_SYSTEM);
		return;
	}

	syslog(LOG_NOTICE, "Configuring ports");
	std::cout << "Boards config finished" << std::endl << "Configuring ports ..." << std::endl;
	exec_result = NO_RESULT;

	parse_and_config_ports();

	if (SUCCESS != exec_result) {
		send_finish_exec_to_sys(command::CONFIG_SYSTEM);
		return;
	}

	syslog(LOG_NOTICE, "Ports configuration finished");
	// setting time in the end of configuration
	// also calls the final board config API
	std::time_t curr_time = std::time(nullptr);
	syslog(LOG_NOTICE, "setting time: %lu", curr_time);
	std::cout << "TIME: " << curr_time << std::endl;
	set_time_to_boards(curr_time);

	if (SUCCESS != exec_result) {
		syslog(LOG_ERR, "Error during setting time to boards and final boards config");
		send_finish_exec_to_sys(command::CONFIG_SYSTEM);
		return;
	}

	syslog(LOG_NOTICE, "Config finished");
	std::cout << "Config finished" << std::endl;
	exec_result = SUCCESS;
	send_finish_exec_to_sys(command::CONFIG_SYSTEM);
	return;
}

void h3_control::parse_and_config_boards()
{
	int slots_num = j_parser.get_slots_number();
	int counter = 0;
	struct board cfg_board;

	auto parse_fail_rutine = [this]() {
		global_err = common_err::ERR_JSON_CONTENT;
		error_report_to_sys(0, NULL);
		exec_result = FAIL;
	};

	if (0 == slots_num) {
		parse_fail_rutine();
		return;
	}

	while (counter < slots_num) {
	
		parse_res result;

		try {
			result = j_parser.parse_cfg_data(cfg_board, counter);
		}
		catch (Json::Exception const& ex) {
			//ex.what();
			result = parse_res::PARS_FAIL;
		}	
	
		if (parse_res::PARS_FAIL == result) {
			parse_fail_rutine();
			return;
		}

		if (parse_res::PARS_NOT_ACT == result) {
			counter++;	// skip this board
			continue;
		}
	
		try {
			if (Glv_DCType::GLV_DC_TYPE_NA == board_type.at(cfg_board.board_type)) {
				parse_fail_rutine();
				return;
			}
		}
		catch (const std::out_of_range& e) {
			parse_fail_rutine();
			return;
		}
	
		syslog(LOG_NOTICE, "Configuring board : %d", cfg_board.slot_index);
		std::cout << "Configuring board : " << cfg_board.slot_index << std::endl;
		board_config(cfg_board);
		counter++;
	}

	exec_result = SUCCESS;
}

void h3_control::parse_and_config_ports()
{
	int board_count = 0;
	int ports_on_board, port_count = 0;
	struct device_port cfg_device_port;
	int slots_num = j_parser.get_slots_number();

	while (board_count < slots_num) {
		ports_on_board = j_parser.get_board_ports_num(board_count);

		while (port_count < ports_on_board) {

			auto parse_fail_rutine = [this]() {
				global_err = common_err::ERR_JSON_CONTENT;
				error_report_to_sys(0, NULL);
				exec_result = FAIL;
			};

			parse_res result;

			try {
				result = j_parser.parse_cfg_data(cfg_device_port,
								   board_count, port_count);
			}
			catch (Json::Exception const& ex) {
				ex.what();
				result = parse_res::PARS_FAIL;
			}	

			if (parse_res::PARS_FAIL == result) {
				parse_fail_rutine();
				return;
			}

			if (parse_res::PARS_NOT_ACT == result) {
				port_count++;	// skip this port
				continue;
			}

			if (cfg_device_port.id[3] == FPD) {

				auto search_host = host_src.find(cfg_device_port.custom_cam_host);

				if (search_host == host_src.end()) {
					syslog(LOG_ERR, "Not defined camera host");
					parse_fail_rutine();
					return;
				}

				auto search_model = camera_model.find
								(cfg_device_port.custom_cam_model);

				if (search_model == camera_model.end()) {
					syslog(LOG_ERR, "Parsed unknown camera model");
					parse_fail_rutine();
					return;
				}
			}
		
			if (cfg_device_port.id[3] == CAN) {

				try {
					if (Glv_BaudRate::GLV_BAUD_RATE_UNKNOWN ==
						baudrate.at(cfg_device_port.custom_can_head_br)) {
						parse_fail_rutine();
						return;
					}

					if (Glv_BaudRate::GLV_BAUD_RATE_UNKNOWN ==
						baudrate.at(cfg_device_port.custom_can_data_br)) {
						parse_fail_rutine();
						return;
					}
				}
				catch (const std::out_of_range& e) {
					parse_fail_rutine();
					return;
				}
			}

			port_config(cfg_device_port);
			port_count++;
		}

		port_count = 0;
		board_count++;
	}

	exec_result = SUCCESS;
}

void h3_control::main_config(struct general_hw hw)
{
	memset(boards_status_arr, 0, sizeof(h3_board_status) * 7);

	syslog(LOG_NOTICE, "Mainboard HW version: %d.%d.%d.%d", hw.hw_version[0],
	       hw.hw_version[1], hw.hw_version[2], hw.hw_version[3]);
	std::cout << "Mainboard HW version: " << hw.hw_version[0] << hw.hw_version[1]
		  << hw.hw_version[2] << hw.hw_version[3] << std::endl;

	syslog(LOG_NOTICE, "Mainboard SW version: %d.%d.%d.%d", hw.sw_version[0],
	       hw.sw_version[1], hw.sw_version[2], hw.sw_version[3]);
	std::cout << "Mainboard SW version: " << hw.sw_version[0] << hw.sw_version[1]
		  << hw.sw_version[2] << hw.sw_version[3] << std::endl;

	exec_result = SUCCESS;
}

void h3_control::board_config(struct board slot_board)
{
	Glv_Rc ret_code;
	Glv_DCType type;
	Glv_CardExist exist;
	Glv_CardReady is_ready = GLV_CARD_NOT_READY;
	// index in array of boards
	int arr_board_index = conv_index_arr(slot_board.slot_index);
	std::string received_type(slot_board.board_type);

	auto fail_report = [this, &slot_board, &arr_board_index](common_err error) {

		std::cout << "Board " << slot_board.slot_index << " error" << std::endl;
		boards_status_arr[arr_board_index].board_st = unit_status::DEAD;
		global_err = error;
		int id[4] = {0};
		id[2] = slot_board.slot_index;
		error_report_to_sys(id, NULL);
	};

	syslog(LOG_NOTICE, "board config: %d %s", slot_board.slot_index, slot_board.board_type);
	syslog(LOG_NOTICE, "board hw ver: %d.%d.%d.%d, board fpga ver: %d.%d.%d.%d",
	       slot_board.hw_version[0], slot_board.hw_version[1], slot_board.hw_version[2],
	       slot_board.hw_version[3], slot_board.fpga_version[0], slot_board.fpga_version[1],
	       slot_board.fpga_version[2], slot_board.fpga_version[3]);

	// initialization
	boards_status_arr[arr_board_index].global_ind = slot_board.slot_index;
	boards_status_arr[arr_board_index].board_st = unit_status::LIVE;

	ret_code = dc_cardExist((Glv_DcNum)slot_board.slot_index, &exist);

	if (GLV_OK != ret_code || GLV_CARD_EXIST != exist) {
		fail_report(common_err::ERR_BOARD_EXIST);
		return;
	}

	ret_code = dc_typeGet((Glv_DcNum)slot_board.slot_index, &type);

	if (GLV_OK != ret_code || type != board_type.at(received_type)) {
		syslog(LOG_ERR, "Board %d has type mismatch with configuration",
								slot_board.slot_index);
		fail_report(common_err::ERR_BOARD_TYPE);
		return;
	}

#if 0
	unsigned int ver;
	ret_code = dc_hwVerGet((Glv_DcNum)slot_board.slot_index, &ver);
	ret_code = dc_fpgaVerGet((Glv_DcNum)slot_board.slot_index, &ver);
	// TODO compare versions
	
	if (GLV_OK != ret_code) {
		syslog(LOG_ERR, "Incompatible HW/SW version of board %d",
								slot_board.slot_index);
		fail_report(common_err::ERR_HW_VERSION);
		return;
	}
#endif
	ret_code = dc_powerDown((Glv_DcNum)slot_board.slot_index);

	if (GLV_OK != ret_code) {
		syslog(LOG_ERR, "Failed to power off board %d", slot_board.slot_index);
		// return the same error code as power up
		fail_report(common_err::ERR_BOARD_PWR_UP);
		return;
	}

	usleep(500);

	ret_code = dc_powerUp((Glv_DcNum)slot_board.slot_index);

	if (GLV_OK != ret_code) {
		syslog(LOG_ERR, "Failed to power up board %d", slot_board.slot_index);
		fail_report(common_err::ERR_BOARD_PWR_UP);
		return;
	}

	// check device ready couple times with delay
	for (int i = 0; i < 5; ++i) {
		ret_code = dc_readyGet((Glv_DcNum)slot_board.slot_index, &is_ready);

		if (GLV_OK == ret_code && GLV_CARD_READY == is_ready) {
			// std::cout << "i = " << i << std::endl;
			break;
		}

		sleep(1);
	}

	if (GLV_CARD_NOT_READY == is_ready) {
		// still the same error as power up
		syslog(LOG_ERR, "Failed to power up board %d", slot_board.slot_index);
		fail_report(common_err::ERR_BOARD_PWR_UP);
		return;
	}

	// top does not have mac
	if (GLV_DC_NUM_TOP != (Glv_DcNum)slot_board.slot_index) {
		ret_code = dc_MACGet((Glv_DcNum)slot_board.slot_index,
				     boards_status_arr[arr_board_index].mac);

		if (GLV_OK != ret_code) {
			syslog(LOG_ERR, "Failed to get MAC for board %d", slot_board.slot_index);
			fail_report(common_err::ERR_BOARD_CONFIG);
			return;
		}

		syslog(LOG_NOTICE, "Setting MAC: %02x:%02x:%02x:%02x:%02x:%02x",
		       boards_status_arr[arr_board_index].mac[0],
		       boards_status_arr[arr_board_index].mac[1],
		       boards_status_arr[arr_board_index].mac[2],
		       boards_status_arr[arr_board_index].mac[3],
		       boards_status_arr[arr_board_index].mac[4],
		       boards_status_arr[arr_board_index].mac[5]);

		std::cout << "Board " << slot_board.slot_index << " MAC: ";
		std::cout << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[0];
		std::cout << ":" << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[1];
		std::cout << ":" << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[2];
		std::cout << ":" << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[3];
		std::cout << ":" << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[4];
		std::cout << ":" << std::hex << std::setfill('0') << std::setw(2)
			  << (int)boards_status_arr[arr_board_index].mac[5] << std::dec
			  << std::endl;


		Glv_SystemMode mode;
		(global_work_mode == MODE_RECORD) ? (mode = GLV_MODE_RECORD) :
						    (mode = GLV_MODE_PLAYBACK);

		ret_code = dc_boardInit((Glv_DcNum)slot_board.slot_index, mode,
					boards_status_arr[arr_board_index].mac);

		if (GLV_OK != ret_code) {
			syslog(LOG_ERR, "Board %d init fail", slot_board.slot_index);
			fail_report(common_err::ERR_BOARD_CONFIG);
			return;
		}
	}
	return;
}

void h3_control::port_config(struct device_port port)
{
	int board_index = conv_index_arr(port.id[2]);
	int arr_port_index = find_free_port_index(board_index);

	// definition for error rutine
	auto error_rutine = [this, &board_index, &arr_port_index, &port]() {
		boards_status_arr[board_index].ports.at(arr_port_index).port_st =
									unit_status::DEAD;
		global_err = common_err::ERR_PORT_CONFIG;

		int id[4] = {0};
		id[0] = port.id[0];
		id[1] = port.id[1];
		id[2] = port.id[2];
		id[3] = port.id[3];
		error_report_to_sys(id, boards_status_arr[board_index]
							.ports.at(arr_port_index).uniq_id);
	};

	if (-1 == arr_port_index) {
		syslog(LOG_ERR, "Error: too many ports for board %d", board_index);
		std::cout << "Error: too many ports for board " << board_index << std::endl;
		//error_rutine();
		return;
	}

	syslog(LOG_NOTICE, "Configuring port: %d.%d.%d.%d", port.id[0], port.id[1],
	       port.id[2], port.id[3]);
	// default initialization
	boards_status_arr[board_index].ports.at(arr_port_index).port_st = unit_status::LIVE;
	boards_status_arr[board_index].ports.at(arr_port_index).port_direction = port.id[0];
	boards_status_arr[board_index].ports.at(arr_port_index).port_type = (p_type)port.id[3];
	boards_status_arr[board_index].ports.at(arr_port_index).stream_id = port.id[1];
	std::strcpy(boards_status_arr[board_index].ports.at(arr_port_index).uniq_id, port.uniq_id);

	// ports with output direction considered as
	// initialized as same as ports with input direction
	if (1 == boards_status_arr[board_index].ports.at(arr_port_index).port_direction) {
		unit_status result = compare_input_device(
		    board_index, boards_status_arr[board_index].ports.at(arr_port_index));

		if (unit_status::DEAD == result)
			error_rutine();

		return;
	}

	if (unit_status::DEAD == boards_status_arr[board_index].board_st) {
		error_rutine();
		return;
	}

	Glv_Rc ret_code;
	Glv_PortConf port_config;
	port_config.id = port.id[1];
	port_config.type = (Glv_PortType)port.id[3];

	// FPD port
	if (port.id[3] == FPD) {
		syslog(LOG_NOTICE, "Camera model: %s", port.custom_cam_model);
		syslog(LOG_NOTICE, "Camera data: hfov - %d, resolution - %dX%d, fps - %d,\
				    format - %s, host - %s",
		       port.custom_cam_hfov, port.custom_cam_res_horz,
		       port.custom_cam_res_vert, port.custom_cam_fps,
		       port.custom_cam_format, port.custom_cam_host);

		std::cout << "Camera model: " << port.custom_cam_model << std::endl;
		std::cout << "Camera data: " << port.custom_cam_hfov << " "
			  << port.custom_cam_res_horz << " " << port.custom_cam_res_vert << " "
			  << port.custom_cam_fps << " " << port.custom_cam_format << " "
			  << port.custom_cam_host << std::endl;

		port_config.params.fpdParams.camModel = camera_model.at(port.custom_cam_model);
		port_config.params.fpdParams.src = host_src.at(port.custom_cam_host);  
		port_config.params.fpdParams.hfov = port.custom_cam_hfov;
		port_config.params.fpdParams.fps = port.custom_cam_fps;
		port_config.params.fpdParams.horz = port.custom_cam_res_horz;
		port_config.params.fpdParams.vert = port.custom_cam_res_vert;

		// TODO parse format
		port_config.params.fpdParams.fmt = 1;
		ret_code = dc_portConfSet((Glv_DcNum)port.id[2], &port_config);

		if (GLV_OK != ret_code) {
			error_rutine();
			return;
		}
	}

	// Ethernet port
	if (port.id[3] == ETH) {
		syslog(LOG_NOTICE, "Configuring Eth port");
		ret_code = dc_portConfSet((Glv_DcNum)port.id[2], &port_config);

		if (GLV_OK != ret_code) {
			error_rutine();
			return;
		}
	}

	// CAN port
	if (port.id[3] == CAN) {
		Glv_CanbMode mode;
		(global_work_mode == MODE_RECORD) ? (mode = GLV_CANB_MODE_RECEIVE)
					     : (mode = GLV_CANB_MODE_TRANSMIT);

		syslog(LOG_NOTICE, "CAN header baud: %s CAN data baud: %s",
		       port.custom_can_head_br, port.custom_can_data_br);

		std::cout << "CAN header baud: " << port.custom_can_head_br
			  << " CAN data baud: " << port.custom_can_data_br << std::endl;

		port_config.params.canbParams.hdrBaud = baudrate.at(port.custom_can_head_br);
		port_config.params.canbParams.dataBaud = baudrate.at(port.custom_can_data_br);
		port_config.params.canbParams.mode = mode;

		ret_code = dc_portConfSet((Glv_DcNum)port.id[2], &port_config);

		if (GLV_OK != ret_code) {
			error_rutine();
			return;
		}
	}

	// USB port
	if (port.id[3] == USB) {
		syslog(LOG_NOTICE, "Configuring USB port");
		std::cout << "Configuring USB" << std::endl;
		ret_code = dc_portConfSet((Glv_DcNum)port.id[2], &port_config);

		if (GLV_OK != ret_code) {
			error_rutine();
			return;
		}
	}

	return;
}

void h3_control::set_time_to_boards(time_t curr_time)
{
	Glv_Rc result = GLV_OK;

	for (auto board : boards_status_arr) {
		if (unit_status::LIVE == board.board_st)
			result = dc_timeSet((Glv_DcNum)board.global_ind, curr_time);

		if (GLV_OK != result)
			break;
	}

	if (GLV_OK != result) {
		exec_result = FAIL;
		return;
	}

	for (auto board : boards_status_arr) {
		unsigned int mask = 0;

		if (unit_status::LIVE != board.board_st)
			continue;

		for (auto port : board.ports) {
			// further ports are not in use too
			if (false == port.is_in_use)
				break;

			if (unit_status::LIVE != port.port_st)
				continue;

			if (FPD == port.port_type && 0 == port.port_direction)
				mask |= 1 << port.stream_id;
		}

		result = dc_boardFinal((Glv_DcNum)board.global_ind, mask);
		mask = 0;

		if (GLV_OK != result)
			break;
	}

	(GLV_OK == result) ? (exec_result = SUCCESS) : (exec_result = FAIL);
}

#if 0
void h3_control::check_FPD_ports_tx()
{
	constexpr unsigned int base_addr = 0x09060000;
	unsigned int frame_val, shift_addr;
	unsigned int cam_frames[24] = {0};
	int frame_ind = 0;
	Glv_Rc result;

	syslog(LOG_NOTICE, "Checking that FPD ports transmit data...");

	for (int index = 0; index < 6; ++index) {

		if (unit_status::DEAD == boards_status_arr[index].board_st)
			continue;

		for (auto port : boards_status_arr[index].ports) {
			if (unit_status::LIVE != port.port_st || false == port.is_in_use)
				continue;

			if (0 == port.port_direction && FPD == port.port_type) {
				shift_addr = 0x01C + 0x100 * port.stream_id;
				result = dc_memRead((Glv_DcNum)boards_status_arr[index].
					global_ind, base_addr, shift_addr, &frame_val);

				if (GLV_OK == result) {
					//std::cout << "Frames: " << frame_val << std::endl;
					cam_frames[frame_ind] = frame_val;
					frame_ind++;
				}
			}
		}
	}

	usleep(1000000);
	frame_ind = 0;
	//std::cout << "after sleep" << std::endl << std::endl;

	for (int index = 0; index < 6; ++index) {

		if (unit_status::DEAD == boards_status_arr[index].board_st)
			continue;

		for (auto port : boards_status_arr[index].ports) {
			if (unit_status::LIVE != port.port_st || false == port.is_in_use)
				continue;

			if (0 == port.port_direction && FPD == port.port_type) {
				shift_addr = 0x01C + 0x100 * port.stream_id;

				result = dc_memRead((Glv_DcNum)boards_status_arr[index].
						global_ind, base_addr, shift_addr, &frame_val);

				if (GLV_OK != result) {
					exec_result = FAIL;
					return;
				}

				if (cam_frames[frame_ind] == frame_val) {
					global_err = common_err::ERR_PORT_TX;
					int id[4] = {0};
					id[1] = port.stream_id;
					id[2] = boards_status_arr[index].global_ind;
					id[3] = FPD;
					error_report_to_sys(id, port.uniq_id);
				}

				frame_ind++;
			}
		}
	}
}
#endif

void h3_control::start_handler()
{
	//std::cout << "Entered to function " << __func__ << std::endl;
	Glv_Rc result = GLV_OK;

	for (auto board : boards_status_arr) {
		if (unit_status::LIVE == board.board_st)
			result = dc_start((Glv_DcNum)board.global_ind);
	}

	(GLV_OK == result) ? (exec_result = SUCCESS) : (exec_result = FAIL);
	syslog(LOG_NOTICE, "Start");
	std::cout << "Start " << std::endl;
	//check_FPD_ports_tx();		// it is workaround
	send_finish_exec_to_sys(command::START);
	//std::cout << "Exit from function " << __func__ << std::endl;
}

void h3_control::stop_handler()
{
	Glv_Rc result = GLV_OK;

	for (auto board : boards_status_arr) {
		if (unit_status::LIVE == board.board_st)
			result = dc_stop((Glv_DcNum)board.global_ind);
	}

	(GLV_OK == result) ? (exec_result = SUCCESS) : (exec_result = FAIL);
	// sleep for a second in order to empty buffers
	usleep(1000);
	syslog(LOG_NOTICE, "Stop");
	std::cout << "Stop " << std::endl;
	send_finish_exec_to_sys(command::STOP);
}


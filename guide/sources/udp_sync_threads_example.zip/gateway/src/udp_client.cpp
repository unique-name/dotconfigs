/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of udp synchronous client.
|
************************************************************************/

#include <udp_client.h>

udp_client::udp_client(boost::asio::io_service &io_service, std::string &addr,
			unsigned int port)
	: ios(io_service), sock(ios, destination)
{
	udp::resolver resolv(io_service);
	udp::resolver::query query(udp::v4(), addr, std::to_string(port));
	udp::resolver::iterator iter = resolv.resolve(query);
	destination = *iter;
}


char * udp_client::receive_from_server()
{
	std::memset(data, 0, BUFF_LEN);
	sock.receive(boost::asio::buffer(data, BUFF_LEN));
	return data;
}

void udp_client::send_to_server(const char *data, size_t size)
{
	sock.send_to(boost::asio::buffer(data, size), destination);
}

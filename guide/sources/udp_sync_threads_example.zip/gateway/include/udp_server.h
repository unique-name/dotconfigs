/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class udp_server that used as
| a gateway for other udp clients in network.
|
************************************************************************/

#ifndef UDP_SERVER_H
#define UDP_SERVER_H

#include <boost/asio.hpp>
#include <boost/bind.hpp>

constexpr unsigned int CYBER_CL_PORT = 6501;
constexpr unsigned int REMOTE_CL_PORT = 6502;
constexpr int BUFF_LEN = 104;
//constexpr char sock_iface[] = "enp2s0";
constexpr char sock_iface[] = "lo";

using boost::asio::ip::udp;

class udp_server
{
      public:
	udp_server(boost::asio::io_service &io_service);
	~udp_server() {};
	char * receive_from_cyber();
	char * receive_from_remote();
	char * receive_from_pcie();
	void send_to_cyber(const char *data, size_t size);
	void send_to_remote(const char *data, size_t size);
	void send_to_pcie(const char *data, size_t size);

      protected:
	boost::asio::io_service &ios;
	udp::endpoint remote_p;
	udp::endpoint cyber_p;
	udp::socket cyber_soc;
	udp::socket remote_soc;
	int sock_fd;
	char cyber_data[BUFF_LEN];
	char remote_data[BUFF_LEN];
	char pcie_data[BUFF_LEN];
};

#endif

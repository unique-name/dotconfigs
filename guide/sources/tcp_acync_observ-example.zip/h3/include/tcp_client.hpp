/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class tcp client. Used by config
| manager in order to connect to H3 manager server and sys manager server.
|
************************************************************************/

#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#include <boost/asio.hpp>
#include <h3_defines.hpp>
#include <observer.hpp>
#include <syslog.h>

using boost::asio::ip::tcp;

class tcp_client : public observable<signature> {
      public:
	tcp_client(const char *hostname, const char *port, boost::asio::io_service &ios);
	void connect(boost::asio::io_service &ios);
	void send_msg(const char *msg, size_t len);
	connection_status get_status() const { return status; }
      private:
	// boost::asio::ip::tcp::socket *socket_;
	tcp::socket *socket_;
	tcp::resolver::iterator iterator;
	connection_status status;
	char data[BUF_LEN];

	void handle_connect(const boost::system::error_code &err, tcp::resolver::iterator &iter);
	void handle_read(const boost::system::error_code &error, size_t bytes_transferred);
};
#endif

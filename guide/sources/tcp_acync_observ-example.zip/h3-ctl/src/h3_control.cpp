/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains partial implementation of class H3 manager.
|
************************************************************************/

#include <h3_control.hpp>
#include <iostream>

boost::mutex m;
boost::condition_variable en_gps_send;

h3_control::h3_control(const std::string &ip) : sys_ip(ip), soc_client(0)
{
	global_work_mode = MODE_RECORD; // TODO temporary for demo
	global_err = common_err::ERR_NONE;
	exec_result = NO_RESULT;
	struct sockaddr_in sa;

	if (0 == inet_pton(AF_INET, ip.c_str(), &(sa.sin_addr)))
		sys_ip = "127.0.0.1";

	syslog(LOG_NOTICE, "H3 manager started");
	std::cout << "H3 manager started" << std::endl;
	connect_to_sys_server();
	init_tcp_callback();
	init_conversion_maps();
	read_saved_board_data();
	run_threads();
}

h3_control::~h3_control()
{
	if (soc_client)
		delete soc_client;

	ios.stop();
}

void h3_control::connect_to_sys_server()
{
	try {
		if (!soc_client)
			soc_client = new tcp_client(sys_ip.c_str(), SYS_SERVER_PORT, ios);
	}
	catch (std::bad_alloc) {
		syslog(LOG_ERR, "Memory allocation failed");
		std::cout << "Memory allocation failed" << std::endl;
		exit(1);
	}
}

void h3_control::periodic_work()
{
	boost::unique_lock<boost::mutex> lock(m);
	en_gps_send.wait(lock);

	while (1) {
		// currenty no need GPS data
#if 0
		struct h3_message<struct gps_location> location;
		int size = sizeof(h3_message<struct gps_location>);
		location.type = GPS_LOCATION;
		gpsLocationGet(&location.params.latitude, &location.params.longitude);

		float lat = ((struct h3_message<struct gps_location> *)(msg))->params.latitude;
		float lon = ((struct h3_message<struct gps_location> *)(msg))->params.longitude;
		syslog(LOG_NOTICE, "GPS_LOCATION from H3 lat: %f lon: %f", lat, lon);

		if (CONNECTED == soc_client->get_status())
			send_message_to_sys((char *)&location, size);
#endif
		boost::this_thread::sleep(boost::posix_time::seconds(1));
	}
}

void h3_control::run_threads()
{
	tcp_service_thread = thread_p(
	    new boost::thread(boost::bind(&boost::asio::io_service::run, boost::ref(ios))));
	boost::thread periodic(&h3_control::periodic_work, this);
	boost::thread sender(&h3_control::message_sender, this);
	tcp_service_thread->join();
	periodic.join();
	sender.join();
}

void h3_control::init_conversion_maps()
{
	board_type = {{"DaughterBoard", Glv_DCType::GLV_DC_TYPE_2},
		      {"TopBoard", Glv_DCType::GLV_DC_TYPE_TOP}};
	baudrate = {{"500 kbps", Glv_BaudRate::GLV_BAUD_RATE_500K},
		    {"1 Mbps", Glv_BaudRate::GLV_BAUD_RATE_1M}};
	host_src = {{"Internal", Glv_PortConfSrc::GLV_INTERNAL_SOURCE},
		    {"External", Glv_PortConfSrc::GLV_EXTERNAL_SOURCE}};
}

void h3_control::init_tcp_callback()
{
	tcp_observ.register_notifier(*soc_client, [this](const char *msg) {
		if (0 == std::strcmp(msg, "connected")) {
			syslog(LOG_NOTICE, "Connected to SYS");
			return;
		}

		if (0 != std::strcmp(msg, "disconnected")) {
			sys_message_handler(msg);
		}
	});
}

static common_err write_to_file(const void *buffer, size_t size, const std::string &name)
{
	std::ofstream f2write(name, std::ofstream::binary);

	if (f2write.is_open())
		f2write.write((char *)buffer, size);
	else
		return common_err::ERR_FILE_ACCESS;

	f2write.close();
	return common_err::ERR_NONE;
}

static common_err read_from_file(const void *buffer, size_t size, const std::string &name)
{
	std::ifstream f2read(name, std::ifstream::binary);

	if (f2read.is_open())
		f2read.read((char *)buffer, size);
	else
		return common_err::ERR_FILE_ACCESS;

	f2read.close();
	return common_err::ERR_NONE;
}

void h3_control::read_saved_board_data()
{
	recorded_board_data data;
	std::string name = "/opt/osr/h3_data";
	syslog(LOG_NOTICE, "Reading board data from /opt/osr/h3_data");

	if (common_err::ERR_NONE == read_from_file(&data, sizeof(recorded_board_data), name)) {
		global_work_mode = data.last_work_mode;
	}
	else
		syslog(LOG_ERR, "Error: file 'h3_data' not found");
}

void h3_control::save_board_data()
{
	std::string name = "/opt/osr/h3_data";
	recorded_board_data data;

	// overwrite data file
	read_from_file(&data, sizeof(recorded_board_data), name);
	data.last_work_mode = global_work_mode;
	syslog(LOG_NOTICE, "Mode set to: %d", global_work_mode);
	std::cout << "Mode set to: " << global_work_mode << std::endl;
	write_to_file(&data, sizeof(recorded_board_data), name);
	syslog(LOG_NOTICE, "Saving board data to /opt/osr/h3_data");
}

void h3_control::message_sender()
{
	tx_buffer buff;

	while (1) {
		buff = tx_queue_to_sys.dequeue();

		if (CONNECTED == soc_client->get_status()) {
			soc_client->send_msg((const char *)buff.msg, buff.size);
			operator delete(buff.msg);
			buff.msg = NULL;
		}
	}
}

void h3_control::sys_message_handler(const char *msg)
{
	command comm_type = (command)(*msg);
	switch (comm_type) {
#if 0
	case	STATUS :
		std::cout << "Handler STATUS" << std::endl;
		break;
#endif

	case command::FINISH_EXEC:
	case command::ERROR_REPORT:
		syslog(LOG_NOTICE, "SYS should not send this command");
		std::cout << "Only cfgm sends this command" << std::endl;
		break;

	case command::SET_MODE: {
		global_work_mode = ((struct message<struct work_mode> *)(msg))->params.w_mode;
		syslog(LOG_NOTICE, "Command SET_MODE new mode: %d", global_work_mode);
		save_board_data();
		exec_result = SUCCESS;
		send_finish_exec_to_sys(command::SET_MODE);
		break;
	}

	case command::GET_MODE: {
		syslog(LOG_NOTICE, "Handler SYS command GET_MODE, mode: %d", global_work_mode);
		struct message<struct work_mode> reply_msg;
		reply_msg.comm_type = command::GET_MODE;
		reply_msg.params.w_mode = global_work_mode;
		send_message_to_sys(&reply_msg, sizeof(struct message<struct work_mode>));
		exec_result = SUCCESS;
		send_finish_exec_to_sys(command::GET_MODE);
		break;
	}

	case command::LOAD_JSON: {
		syslog(LOG_NOTICE, "Handler SYS command LOAD_JSON");
		char path[FILENAME_SIZE];
		std::strcpy(path, ((struct message<struct json> *)(msg))->params.path_to_file);
		load_json_file(path);
		break;
	}

#if 0
	case GPS_LOCATION:
		syslog(LOG_NOTICE, "Handler SYS command GPS_LOCATION");
		en_gps_send.notify_one();
		exec_result = SUCCESS;
		send_finish_exec_to_sys(GPS_LOCATION);
		break;
#endif

	case command::CONFIG_SYSTEM:
		syslog(LOG_NOTICE, "Handler SYS command CONFIG_SYSTEM");
		config_system();
		break;

	case command::START: {
		syslog(LOG_NOTICE, "SYS command START");
		start_handler();
		break;
	}

	case command::STOP: {
		syslog(LOG_NOTICE, "SYS command STOP");
		stop_handler();
		break;
	}

	default:
		syslog(LOG_NOTICE, "Wrong SYS command type");
		std::cout << "Wrong SYS command type" << std::endl;
	}
}

void h3_control::error_report_to_sys(const int id[4], const char *uniq_id)
{
	struct message<struct err_report> msg;
	msg.comm_type = command::ERROR_REPORT;

	struct err_report report = {global_err, {0, 0, 0, 0}, {0}};

	if (id) {
		report.id[0] = id[0];
		report.id[1] = id[1];
		report.id[2] = id[2];
		report.id[3] = id[3];
	}

	if (uniq_id) {
		std::strcpy(report.uniq_id, uniq_id);
		//std::cout << report.uniq_id << std::endl;
	}

	syslog(LOG_NOTICE, "Error occured. Code: %d ID: %d%d%d%d", static_cast<int>(global_err),
	       report.id[0], report.id[1], report.id[2], report.id[3]);

	std::cout << "Error occured. Code: " << static_cast<int>(global_err)
		  << " ID: " << report.id[0] << " " << report.id[1] << " " << report.id[2] << " "
		  << report.id[3] << std::endl;

	msg.params = report;
	send_message_to_sys(&msg, sizeof(struct message<struct err_report>));
}

void h3_control::send_finish_exec_to_sys(command which_comm)
{
	struct message<struct finish_exec> reply;

	reply.params.res = (result)exec_result;
	exec_result = NO_RESULT;
	reply.params.which_command = which_comm;
	reply.comm_type = command::FINISH_EXEC;
	send_message_to_sys(&reply, sizeof(struct message<struct finish_exec>));
}

void h3_control::send_message_to_sys(const void *msg, size_t size)
{
	tx_buffer buff;

	try {
		buff.msg = operator new(size);
	}
	catch (std::bad_alloc) {
		syslog(LOG_NOTICE, "Memory allocation failed");
		std::cout << "Memory allocation failed" << std::endl;
		exit(1);
	}

	std::memcpy(buff.msg, msg, size);
	buff.size = size;
	tx_queue_to_sys.enqueue(buff);
}


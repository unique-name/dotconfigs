/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implemetation of class tcp session.
|
************************************************************************/

#include <boost/bind.hpp>
#include <iostream>
#include <tcp_session.hpp>

using boost::asio::ip::tcp;

tcp_session::tcp_session(boost::asio::io_service &io_service) : socket_(io_service)
{
}
void tcp_session::start()
{
	socket_.async_read_some(boost::asio::buffer(data, sizeof(size_t)),
				boost::bind(&tcp_session::handle_read, this,
					    boost::asio::placeholders::error,
					    boost::asio::placeholders::bytes_transferred));
}

void tcp_session::handle_read(const boost::system::error_code &error, size_t bytes_transferred)
{
	if (error) {
		notify("disconnected");
		syslog(LOG_NOTICE, "Client disconnected");
		std::cout << "Client disconnected" << std::endl;
		return;
	}
	else {
		// obtain size of message and then read message itself
		size_t size = *data;
		boost::asio::read(socket_, boost::asio::buffer(data, size));
		notify(data);
		socket_.async_read_some(boost::asio::buffer(data, sizeof(size_t)),
					boost::bind(&tcp_session::handle_read, this,
						    boost::asio::placeholders::error,
						    boost::asio::placeholders::bytes_transferred));
	}
}

void tcp_session::send_msg(const char *msg, size_t size)
{
	// send size of message and then message itself
	boost::asio::write(socket_, boost::asio::buffer(&size, sizeof(size_t)));
	boost::asio::write(socket_, boost::asio::buffer(msg, size));
}

/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: main function of H3 manager.
|
************************************************************************/

#include <h3_control.hpp>

int main(int argc, char *argv[])
{
	if (argc > 1) {
		std::string ip(argv[1]);
		h3_control manager(ip);
	}
	else
		h3_control manager;

	return 0;
}

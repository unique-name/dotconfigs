/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class tcp server that used
| by H3 manager. Based on class session.
|
************************************************************************/

#ifndef TCP_SERVER_H
#define TCP_SERVER_H

#include <common_structs.hpp>
#include <observer.hpp>
#include <tcp_session.hpp>

using boost::asio::ip::tcp;

class tcp_server : public observable<signature>, public observer<tcp_session, signature> {
      public:
	tcp_server(boost::asio::io_service &ios_, short port);
	void send_msg(const char *msg, size_t size);
	void accept_client();
	connection_status get_status() const { return status; }
      protected:
	connection_status status;
	std::unique_ptr<tcp_session> session_;
	boost::asio::io_service &ios;
	tcp::acceptor acceptor_;

	void handle_accept(const boost::system::error_code &error);
};
#endif

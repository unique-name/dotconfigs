/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: main function of H3 CAN Eth gateway project.
|
************************************************************************/

#include <iostream>
#include <gateway_controller.h>

int main(int argc, char *argv[])
{
	if (argc > 1) {
		try {
			std::string configfile(argv[1]);
			gateway_controller gateway(configfile);
		} catch (std::runtime_error &e) {
			std::cout << e.what() << std::endl;
			exit(1);
		}
	}

	else {
		std::cout << "Not provided full path and name of config file" << std::endl;
		exit(1);
	}

	return 0;
}

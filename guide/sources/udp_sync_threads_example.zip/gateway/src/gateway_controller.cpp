/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of class gateway_controller.
|
************************************************************************/

#include <udp_server.h>
#include <gateway_controller.h>
#include <iostream>
#include <fstream>
#include <thread>

gateway_controller::gateway_controller(std::string &configfile) : server(ios)
{
	std::cout << "Gateway started" << std::endl;
	cyber_conn = false;
	remote_conn = false;
	err_occured = false;
	cyber_tx_mask = 0;
	remote_tx_mask = 0;
	pcie_tx_mask = 0;

	parse_configfile(configfile);

	if (0 != can_init(&mc)) {
		err_occured = true;
		throw std::runtime_error("Failed to run can_init");
	}

	ios.run();
	run_threads();
}

gateway_controller::~gateway_controller()
{
	ios.stop();
	can_release(&mc);
	std::cout << "Gateway stopped" << std::endl;
}

void gateway_controller::parse_configfile(std::string &configfile)
{
	std::ifstream config_file(configfile);
	std::string word;
	std::map<std::string, unsigned int *> tx_mask = {
	{"pcie:", &pcie_tx_mask},
	{"cyber:", &cyber_tx_mask},
	{"remote:", &remote_tx_mask}};

	if (!config_file.is_open()) {
		err_occured = true;
		throw std::runtime_error("Failed to open config file");
	}

	// ignore comments line
	std::getline(config_file, word);

	while (!config_file.eof()) {
		std::getline(config_file, word, ' ');

		try {
			unsigned int *current = tx_mask.at(word);
			std::getline(config_file, word);

			if ((word.find("cyber") != std::string::npos)) {
				*current |= CYBER;
			}

			if ((word.find("remote") != std::string::npos)) {
				*current |= REMOTE;
			}

			if ((word.find("pcie") != std::string::npos)) {
				*current |= PCIE;
			}

		} catch (const std::out_of_range& e) {
			break;
		}

		unsigned int wrong_mask = PCIE |  REMOTE | CYBER;

		if (cyber_tx_mask == wrong_mask || remote_tx_mask == wrong_mask ||
				pcie_tx_mask == wrong_mask) {
			throw std::runtime_error("Gateway config file arsing error");
		}
	}

	config_file.close();
}

void gateway_controller::run_threads()
{
	std::cout << "Running threads" << std::endl;
	std::thread sender(&gateway_controller::message_sender, this);
	std::thread cyber(&gateway_controller::cyber_gw, this);
	std::thread remote(&gateway_controller::remote_gw, this);
	std::thread pcie(&gateway_controller::pcie_gw, this);
	// comes here in case errors
	cyber.join();
	remote.join();
	pcie.join();
	sender.join();
}

void gateway_controller::cyber_gw()
{
	void * data_p;

	try {
		while (false == err_occured) {
			data_p = server.receive_from_cyber();

			if (std::strcmp((char *)data_p, "hello") == 0) {
				std::cout << "Cyber client connected" << std::endl;
				cyber_conn = true;
				// reply with ack
				send_message("gw_ack", std::strlen("gw_ack"), CYBER);
				continue;
			}

			// resending received message according to spec
			if (true == cyber_conn)
				send_message(data_p, BUFF_LEN, cyber_tx_mask);
		}
	} catch (const std::runtime_error& err) {
		err_occured = true;
		std::cout << err.what() << std::endl;
	}
}

void gateway_controller::remote_gw()
{
	void * data_p;

	try {
		while (false == err_occured) {
			data_p = server.receive_from_remote();

			if (std::strcmp((char *)data_p, "hello") == 0) {
				std::cout << "Denverton remote client connected" << std::endl;
				remote_conn = true;
				// reply with ack
				send_message("gw_ack", std::strlen("gw_ack"), REMOTE);
				continue;
			}

			// resending received message according to spec
			if (true == remote_conn)
				send_message(data_p, BUFF_LEN, remote_tx_mask);
		}
	} catch (const std::runtime_error& err) {
		err_occured = true;
		std::cout << err.what() << std::endl;
	}
}

void gateway_controller::pcie_gw()
{
	void *data_p;

	try {
		while (false == err_occured) {
			data_p = server.receive_from_pcie();
			// resending received message to all other sides
			send_message(data_p, BUFF_LEN, pcie_tx_mask);
		}
	} catch (const std::runtime_error& err) {
		err_occured = true;
		std::cout << err.what() << std::endl;
	}
}

void gateway_controller::message_sender()
{
	tx_buffer tx_buff;

	try {
		while (false == err_occured) {
			tx_buff = tx_queue.dequeue();
	
			if (tx_buff.tx_target & CYBER) {
				server.send_to_cyber((const char *)tx_buff.msg, tx_buff.size);
			}
	
			if (tx_buff.tx_target & REMOTE) {
				server.send_to_remote((const char *)tx_buff.msg, tx_buff.size);
			}

			if (tx_buff.tx_target & PCIE) {
				if (0 != can_to_fpga(*((struct osr_canfd_tx *)(tx_buff.msg)), &mc))
					throw std::runtime_error("Failed to run can_to_fpga");
			}

			operator delete(tx_buff.msg);
			std::memset(&tx_buff, 0, sizeof(tx_buffer));
		}
	} catch (const boost::system::system_error &error) {
		err_occured = true;
		operator delete(tx_buff.msg);
		std::cout << "Cant send message via socket" << std::endl;
	} catch (std::runtime_error &e) {
		err_occured = true;
		operator delete(tx_buff.msg);
		std::cout << e.what() << std::endl;
	}
}

void gateway_controller::send_message(const void *msg, size_t size, const int tx_target)
{
	tx_buffer buff;

	try {
		buff.msg = operator new(size);
	} catch (std::bad_alloc) {
		err_occured = true;
		throw std::runtime_error("Memory allocation failed");
	}

	std::memcpy(buff.msg, msg, size);
	buff.size = size;
	buff.tx_target = tx_target;
	tx_queue.enqueue(buff);
}


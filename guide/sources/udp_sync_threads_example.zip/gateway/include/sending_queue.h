/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration and implementation of class that
| receives messages that need to be transmitted in queue and sends them
| by order.
|
************************************************************************/

#include <condition_variable>
#include <mutex>
#include <queue>

constexpr unsigned int PCIE = 1 << 0;
constexpr unsigned int CYBER = 1 << 1;
constexpr unsigned int REMOTE = 1 << 2;

typedef struct tx_buffer {
	size_t size;
	int tx_target;
	void *msg;
} tx_buffer;

class sending_queue {
      private:
	std::queue<tx_buffer> q;
	mutable std::mutex m;
	std::condition_variable condition;

      public:
	void enqueue(const tx_buffer buff);
	tx_buffer dequeue();
};

inline void sending_queue::enqueue(const tx_buffer buff)
{
	std::lock_guard<std::mutex> lock(m);
	q.push(buff);
	condition.notify_one();
}

inline tx_buffer sending_queue::dequeue()
{
	std::unique_lock<std::mutex> lock(m);

	while (q.empty())
		condition.wait(lock);

	tx_buffer buff = q.front();
	q.pop();
	return buff;
}

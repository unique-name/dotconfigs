#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <iostream>
#include <tcp_server.hpp>
#include <h3_defines.hpp>
#include <common_structs.hpp>

using boost::asio::ip::tcp;

int main(int argc, char *argv[])
{
	if (argc < 2) {
		std::cout << "Please enter the path to the configfile" << std::endl;
		exit(1);
	}

	boost::asio::io_service io_service;
	tcp_server s(io_service, 6600);
	observer<tcp_server, signature> obs;

	obs.register_notifier(s, [](const char *msg) {
		if (*(command *)msg == command::ERROR_REPORT) {
			struct err_report err_msg =
				((struct message<struct err_report> *)msg)->params;
				std::cout << "Error: " << err_msg.id[0] << " " <<
				err_msg.id[1] << " " << err_msg.id[2] << " " <<
				err_msg.id[3] << std::endl;
			}
		});

	s.accept_client();

	boost::thread t(boost::bind(&boost::asio::io_service::run,
				    boost::ref(io_service)));

	std::getchar();
	std::cout << "Sending command load json" << std::endl;
	command comm = command::LOAD_JSON;
	struct message<struct json> msg1;
	msg1.comm_type = comm;

	std::strcpy(msg1.params.path_to_file, argv[1]);
	s.send_msg((char*)&msg1, sizeof(struct message<struct json>));

	std::cout << "Sending command get mode" << std::endl;
	comm = command::GET_MODE;
	s.send_msg((char*)&comm, sizeof(command));

	std::cout << "Sending command set mode" << std::endl;
	struct message<struct work_mode> msg2;
	msg2.comm_type = command::SET_MODE;
	msg2.params.w_mode = MODE_RECORD;
	s.send_msg((char*)&msg2, sizeof(struct message<struct work_mode>));

	std::cout << "Sending command config system" << std::endl;
	comm = command::CONFIG_SYSTEM;
	s.send_msg((char*)&comm, sizeof(command));
	usleep(1000000);

	std::getchar();
	std::cout << "Sending command start" << std::endl;
	comm = command::START;
	s.send_msg((char*)&comm, sizeof(command));

	std::getchar();
	std::cout << "Sending command stop" << std::endl;
	comm = command::STOP;
	s.send_msg((char*)&comm, sizeof(command));

	std::getchar();
	std::cout << "Sending command start" << std::endl;
	comm = command::START;
	s.send_msg((char*)&comm, sizeof(command));

	std::getchar();
	std::cout << "Sending command stop" << std::endl;
	comm = command::STOP;
	s.send_msg((char*)&comm, sizeof(command));

	std::getchar();
	std::cout << "Sending command start" << std::endl;
	comm = command::START;
	s.send_msg((char*)&comm, sizeof(command));

	std::getchar();
	std::cout << "Sending command stop" << std::endl;
	comm = command::STOP;
	s.send_msg((char*)&comm, sizeof(command));

	t.join();

	return 0;
}

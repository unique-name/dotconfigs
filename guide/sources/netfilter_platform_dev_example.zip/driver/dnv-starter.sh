#!/bin/bash

#this flag makes script exit in error case
set -e

gw_ip=$1
net_iface_name=$2

sudo modprobe can_dev
sudo modprobe dnv_driver ip="$gw_ip"
sudo modprobe dnv_netfilter iface_name="$net_iface_name"
sudo ifconfig can0 up

/************************************************************************
| Copyright (c) OSR Enterprises AG, 2017.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: Interface used to enable a signaling mechanism between
|	       objects.
|
************************************************************************/

#ifndef OBSERVER_H
#define OBSERVER_H
#include <boost/signals2.hpp>

// T - Observable object type
// S - Function signature
template <class T, typename S> class observer {
	using F = std::function<S>;

      public:
	void register_notifier(T &obj, F f)
	{
		connection_ = obj.connect_notifier(std::forward<F>(f));
	}

      protected:
	boost::signals2::scoped_connection connection_;
};

// S - Function signature
template <typename S> class observable {
      public:
	boost::signals2::scoped_connection connect_notifier(std::function<S> f)
	{
		return notify.connect(std::move(f));
	}

      protected:
	boost::signals2::signal<S> notify;
};
#endif

/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class tcp session that supports
| class tcp server.
|
************************************************************************/

#ifndef TCP_SESSION_H
#define TCP_SESSION_H

#include <boost/asio.hpp>
#include <h3_defines.hpp>
#include <observer.hpp>
#include <syslog.h>

class tcp_session : public observable<signature> {
      public:
	tcp_session(boost::asio::io_service &io_service);
	boost::asio::ip::tcp::tcp::socket &get_socket() { return socket_; }
	void start();
	void send_msg(const char *msg, size_t size);

      protected:
	char data[BUF_LEN];
	boost::asio::ip::tcp::tcp::socket socket_;

	void handle_read(const boost::system::error_code &error, size_t bytes_transferred);
	void handle_write(const boost::system::error_code &error);
};
#endif

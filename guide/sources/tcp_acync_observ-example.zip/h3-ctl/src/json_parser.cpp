/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of class json parser used by
| config manager.
|
************************************************************************/

#include <json_parser.hpp>
#include <cstring>
#include <fstream>
#include <iostream>

// helper function for parsing ID string and fill parsed data into array
static void parse_str_to_arr(int *arr, char *str)
{
	for (int index = 0, runner = 0; index < 4; ++index) {
		arr[index] = str[runner] - '0';

		if (str[runner + 1] <= '9' && str[runner + 1] >= '0') {
			runner++;
			arr[index] *= 10;
			arr[index] += str[runner] - '0';
		}
		runner += 2;
	}
}

json_parser::json_parser()
{
	board_slots_num = 0;
}

common_err json_parser::load_json_file(const char *filename)
{
	syslog(LOG_NOTICE, "json file path: %s", filename);
	Json::Reader reader;
	common_err result = common_err::ERR_NONE;
	std::ifstream json_file(filename);

	if (!json_file.is_open())
		result = common_err::ERR_JSON_FILE;

	else {
		if (false == reader.parse(json_file, json_obj, false))
			result = common_err::ERR_JSON_CONTENT;
	}

	return result;
}

parse_res json_parser::parse_cfg_data(struct general_hw &cfg_general_hw)
{
	char temp_str[20];
	Json::Value sub_obj = json_obj["Hardware"];

	if (sub_obj["name"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(cfg_general_hw.name, sub_obj["name"].asString().c_str());

	if (sub_obj["serialNumber"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(cfg_general_hw.serial_number, sub_obj["serialNumber"].asString().c_str());

	if (sub_obj["numOfSlots"].empty())
		return parse_res::PARS_FAIL;

	board_slots_num = sub_obj["numOfSlots"].asInt();

	if (sub_obj["hwVersion"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(temp_str, sub_obj["hwVersion"].asString().c_str());
	parse_str_to_arr(cfg_general_hw.hw_version, temp_str);

	if (sub_obj["swVersion"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(temp_str, sub_obj["swVersion"].asString().c_str());
	parse_str_to_arr(cfg_general_hw.sw_version, temp_str);

	syslog(LOG_NOTICE, "Parsed general data: name - %s, serial - %s \
	hw ver- %d%d%d%d, sw ver - %d%d%d%d",
	       cfg_general_hw.name, cfg_general_hw.serial_number, cfg_general_hw.hw_version[0],
	       cfg_general_hw.hw_version[1], cfg_general_hw.hw_version[2],
	       cfg_general_hw.hw_version[3], cfg_general_hw.sw_version[0],
	       cfg_general_hw.sw_version[1], cfg_general_hw.sw_version[2],
	       cfg_general_hw.sw_version[3]);
	return parse_res::PARS_SUCC;
}

parse_res json_parser::parse_cfg_data(struct board &cfg_board, int board_num)
{
	char temp_str[20];
	Json::Value sub_obj = json_obj["BoardsCollection"][board_num];

	if (sub_obj["SlotIndex"].empty())
		return parse_res::PARS_FAIL;

	cfg_board.slot_index = sub_obj["SlotIndex"].asInt();

	// Check that board does not have active ports, so no need to activate it
	bool empty = true;
	Json::Value temp_obj = json_obj["BoardsCollection"][board_num]["PortsCollection"];

	for (int port = 0; port < get_board_ports_num(board_num); ++port) {

		if (!temp_obj[port]["Device"].isNull()) {
			empty = false;
			break;
		}
	}

	if (empty) {
		syslog(LOG_NOTICE, "Board %d has no active slots", cfg_board.slot_index);
		return parse_res::PARS_NOT_ACT;
	}

	if (sub_obj["BoardType"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(cfg_board.board_type, sub_obj["BoardType"].asString().c_str());

	if (sub_obj["HWVersion"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(temp_str, sub_obj["HWVersion"].asString().c_str());
	parse_str_to_arr(cfg_board.hw_version, temp_str);

	if (sub_obj["FPGAVersion"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(temp_str, sub_obj["FPGAVersion"].asString().c_str());
	parse_str_to_arr(cfg_board.fpga_version, temp_str);

	syslog(LOG_NOTICE, "Parsed board data: slot index - %d, board type - %s \
	hw ver - %d%d%d%d, sw ver - %d%d%d%d",
	       cfg_board.slot_index, cfg_board.board_type, cfg_board.hw_version[0],
	       cfg_board.hw_version[1], cfg_board.hw_version[2], cfg_board.hw_version[3],
	       cfg_board.fpga_version[0], cfg_board.fpga_version[1], cfg_board.fpga_version[2],
	       cfg_board.fpga_version[3]);
	return parse_res::PARS_SUCC;
}

parse_res json_parser::parse_cfg_data(struct device_port &cfg_device_port, int board_num,
					   int port_num)
{
	char temp_str[STR_LEN];
	Json::Value sub_obj = json_obj["BoardsCollection"][board_num]["PortsCollection"][port_num];

	memset(&cfg_device_port, 0, sizeof(struct device_port));

	if (sub_obj["Index"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(temp_str, sub_obj["Index"].asString().c_str());
	parse_str_to_arr(cfg_device_port.id, temp_str);

	if (sub_obj["Device"].isNull())
		return parse_res::PARS_NOT_ACT; // Device is not connected/powered on

	syslog(LOG_NOTICE, "Parsed device port data: id - %d%d%d%d", cfg_device_port.id[0],
	       cfg_device_port.id[1], cfg_device_port.id[2], cfg_device_port.id[3]);

	if (sub_obj["Device"]["UniqueIdentifier"].empty())
		return parse_res::PARS_FAIL;

	std::strcpy(cfg_device_port.uniq_id, sub_obj["Device"]["UniqueIdentifier"]
									.asString().c_str());
	// Camera
	if (1 == cfg_device_port.id[3]) {
		Json::Value cust_data_obj = sub_obj["Device"]["FieldsSelections"];

		if (cust_data_obj.empty())
			return parse_res::PARS_FAIL;

		int size = cust_data_obj.size();
		temp_str[0] = '\0';

		for (int ind = 0; ind < size; ++ind) {
			if (cust_data_obj[ind]["FieldName"].asString() == "Resolution") {
				std::strcpy(temp_str, cust_data_obj[ind]["Value"].asString()
										.c_str());
				break;
			}
		}

		if (strlen(temp_str) == 0)
			return parse_res::PARS_FAIL;

		cfg_device_port.custom_cam_res_horz = std::stoi(temp_str);

		for (int ind = 0; ind < (int)std::strlen(temp_str); ++ind) {
			if (temp_str[ind] == 'X') {
				cfg_device_port.custom_cam_res_vert = std::stoi(temp_str + ind + 1);
				break;
			}

			if (ind == (int)std::strlen(temp_str))
				return parse_res::PARS_FAIL;
		}

		for (int ind = 0; ind < size; ++ind) {
			if (cust_data_obj[ind]["FieldName"].asString() == "Host") {
				std::strcpy(cfg_device_port.custom_cam_host,
					    cust_data_obj[ind]["Value"].asString().c_str());
				break;
			}
		}

		if (strlen(cfg_device_port.custom_cam_host) == 0)
			return parse_res::PARS_FAIL;

		for (int ind = 0; ind < size; ++ind) {
			if (cust_data_obj[ind]["FieldName"].asString() == "Frame Rate") {
				cfg_device_port.custom_cam_fps = cust_data_obj[ind]["Value"].asInt();
				break;
			}
		}

		if (cfg_device_port.custom_cam_fps == 0)
			return parse_res::PARS_FAIL;

		for (int ind = 0; ind < size; ++ind) {
			if (cust_data_obj[ind]["FieldName"].asString() == "Format") {
				std::strcpy(cfg_device_port.custom_cam_format,
					    cust_data_obj[ind]["Value"].asString().c_str());
				break;
			}
		}

		if (strlen(cfg_device_port.custom_cam_format) == 0)
			return parse_res::PARS_FAIL;

		for (int ind = 0; ind < size; ++ind) {
			if (cust_data_obj[ind]["FieldName"].asString() == "HFOV") {
				cfg_device_port.custom_cam_hfov = cust_data_obj[ind]["Value"]
											.asInt();
				break;
			}
		}

		if (cfg_device_port.custom_cam_hfov == 0)
			return parse_res::PARS_FAIL;

		syslog(LOG_NOTICE, "Parsed Camera data: hfov - %d, \
		resolution - %dX%d, fps - %d, format - %s",
		       cfg_device_port.custom_cam_hfov, cfg_device_port.custom_cam_res_horz,
		       cfg_device_port.custom_cam_res_vert, cfg_device_port.custom_cam_fps,
		       cfg_device_port.custom_cam_format);
	}

	// Eth
	if (2 == cfg_device_port.id[3]) {
		// currently nothing to do
		syslog(LOG_NOTICE, "Ethernet port has no data to parse");
	}

	// CAN
	if (3 == cfg_device_port.id[3]) {
		Json::Value cust_data_obj = sub_obj["Device"]["FieldsSelections"];
		if (cust_data_obj.empty())
			return parse_res::PARS_FAIL;

		if (cust_data_obj[1]["FieldName"].asString() == "Header Bit Rate") {
			std::strcpy(cfg_device_port.custom_can_head_br,
				    cust_data_obj[1]["Value"].asString().c_str());
		}
		if (cust_data_obj[2]["FieldName"].asString() == "Data Bit Rate") {
			std::strcpy(cfg_device_port.custom_can_data_br,
				    cust_data_obj[2]["Value"].asString().c_str());
		}

		syslog(LOG_NOTICE, "Parsed CAN data: head bitrate - %s, data bitrate - %s",
		       cfg_device_port.custom_can_head_br, cfg_device_port.custom_can_data_br);
	}

	return parse_res::PARS_SUCC;
}

int json_parser::get_board_ports_num(int board_num) const
{
	return json_obj["BoardsCollection"][board_num]["PortsCollection"].size();
}

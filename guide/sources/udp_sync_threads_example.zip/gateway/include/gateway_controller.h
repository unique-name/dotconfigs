/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class gateway_controller that
| used as network gateway in H3 in order to manage sending of CAN data.
|
************************************************************************/

#ifndef GATEWAY_H
#define GATEWAY_H

#include <syslog.h>
#include <sending_queue.h>
#include <udp_server.h>
#include <can_to_fpga.h>

class gateway_controller
{
    public:
	explicit gateway_controller(std::string &configfile);
	~gateway_controller();
	gateway_controller(const gateway_controller &) = delete;
	gateway_controller &operator=(const gateway_controller &) = delete;

     private:
	boost::asio::io_service ios;
	udp_server server;
	sending_queue tx_queue;
	unsigned int cyber_tx_mask, remote_tx_mask, pcie_tx_mask;
	bool cyber_conn, remote_conn;
	bool err_occured;
	struct meta_can mc;

	void parse_configfile(std::string &configfile);
	void run_threads();
	// implements flow of rx packet from cyber side
	void cyber_gw();
	// implements flow of rx packets from denverton side
	void remote_gw();
	// implements flow of rx packets from kernel side
	void pcie_gw();
	void message_sender();
	void send_message(const void *msg, size_t size, const int tx_target);
};

#endif

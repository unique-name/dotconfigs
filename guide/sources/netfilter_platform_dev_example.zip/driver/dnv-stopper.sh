#!/bin/bash

sudo modprobe -r dnv_netfilter
sudo modprobe -r dnv_driver
sudo modprobe -r can_dev

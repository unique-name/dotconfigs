/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains declaration of class udp_client that defines
| synchronous udp client based on boost in order to test udp_server
| and gateway.
|
************************************************************************/

#ifndef UDP_CLIENT_H
#define UDP_CLIENT_H

#include <boost/asio.hpp>
#include <udp_server.h>


using boost::asio::ip::udp;

class udp_client
{
     public:
	udp_client(boost::asio::io_service &io_service, std::string &addr, unsigned int port);
	~udp_client() {sock.close();};
	char * receive_from_server();
	void send_to_server(const char *data, size_t size);

     protected:
	boost::asio::io_service &ios;
	udp::endpoint destination;
	udp::socket sock; 
	char data[BUFF_LEN];
};

#endif

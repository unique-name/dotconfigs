/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of class tcp client.
|
************************************************************************/

#include <exception>
#include <iostream>
#include <tcp_client.hpp>

using boost::asio::ip::tcp;

tcp_client::tcp_client(const char *hostname, const char *port, boost::asio::io_service &ios)
    : socket_(0), status(DISCONNECTED)
{
	tcp::resolver resolver(ios);
	tcp::resolver::query query(tcp::v4(), hostname, port);
	iterator = resolver.resolve(query);
	connect(ios);
}

void tcp_client::handle_connect(const boost::system::error_code &err, tcp::resolver::iterator &iter)
{
	if (!err) {
		socket_->async_read_some(boost::asio::buffer(data, sizeof(size_t)),
					 boost::bind(&tcp_client::handle_read, this,
						     boost::asio::placeholders::error,
						     boost::asio::placeholders::bytes_transferred));
		status = CONNECTED;
		syslog(LOG_NOTICE, "Connected to server");
		std::cout << "Connected to server" << std::endl;
		notify("connected");
	}

	else {
		socket_->async_connect(*iter,
				       boost::bind(&tcp_client::handle_connect, this,
						   boost::asio::placeholders::error, iterator));
	}
}

void tcp_client::connect(boost::asio::io_service &ios)
{
	if (socket_ != 0) {
		socket_->close();
		free(socket_);
	}

	socket_ = new tcp::socket(ios);
	tcp::endpoint endpoint = *iterator;
	socket_->async_connect(endpoint, boost::bind(&tcp_client::handle_connect, this,
						     boost::asio::placeholders::error, iterator));
}

void tcp_client::send_msg(const char *msg, size_t size)
{
	// send size of message and then message itself
	boost::asio::write(*socket_, boost::asio::buffer(&size, sizeof(size_t)));
	boost::asio::write(*socket_, boost::asio::buffer(msg, size));
}

void tcp_client::handle_read(const boost::system::error_code &error, size_t bytes_transferred)
{
	if (error) {
		status = DISCONNECTED;
		notify("disconnected");
		syslog(LOG_NOTICE, "Server disconnected");
		std::cout << "Server disconnected" << std::endl;
		return;
	}
	else {
		size_t size = *data;
		boost::asio::read(*socket_, boost::asio::buffer(data, size));
		notify(data);

		socket_->async_read_some(boost::asio::buffer(data, sizeof(size_t)),
					 boost::bind(&tcp_client::handle_read, this,
						     boost::asio::placeholders::error,
						     boost::asio::placeholders::bytes_transferred));
	}
}

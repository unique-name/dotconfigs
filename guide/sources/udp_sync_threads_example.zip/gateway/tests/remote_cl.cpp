/************************************************************************
| Copyright (c) OSR Enterprises AG, 2018.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: tester for CAN Eth gateway project.
|
************************************************************************/

#include <gateway_controller.h>
#include <udp_client.h>
#include <iostream>
#include <thread>

int main(int argc, char *argv[])
{
	boost::asio::io_service ios;

	if (argc < 1) {
		std::cout << "You need to provide IP address of Gateway" << std::endl;
		exit(1);
	}

	std::string ip = argv[1];
	udp_client client(ios, ip, REMOTE_CL_PORT);

	std::thread receiver([&client](){
		while (true) {
			void * data_p;
			data_p = client.receive_from_server();	
			std::cout << "REMOTE: Received message: " << (char *)data_p << std::endl;
		}
	});

	std::string message = "hello";
	client.send_to_server(message.c_str(), message.size());


	while (true) {
		std::cout << "Enter message you want to send" << std::endl;
		std::cin >> message;

		client.send_to_server(message.c_str(), message.size());
	}

	receiver.join();
	return 0;
}


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netdevice.h>
#include <linux/can/dev.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/inet.h>
//#include <linux/tcp.h>

#define UDP 17
#define TCP 6
#define GW_PORT 6502
#define OSR_HEADER_SIZE 32
#define NF_IP_PRE_ROUTING 0

static char *iface_name;
static struct nf_hook_ops h_ops;
static struct net_device *gw_net_dev;
static struct net_device *can_net_dev;
static struct net *net;
extern void report_gw_conn(void);

module_param(iface_name, charp, 0000);

struct osr_canfd_tx {
	u8 osr_hdr[OSR_HEADER_SIZE];
	struct canfd_frame cfd;
};

static void sender(struct canfd_frame data)
{
	struct canfd_frame *canfd;
	struct sk_buff *skb;

	skb = alloc_canfd_skb(can_net_dev, &canfd);

	if (!skb) {
		pr_emerg("Failed to create sk_buff for CAN\n");
		return;
	}

	memcpy(canfd, &data, sizeof(struct canfd_frame));
	pr_debug("Netfilter: received CAN id: %u len: %u\n", canfd->can_id, canfd->len);
	pr_debug("Data: %02X %02X %02X %02X %02X %02X %02X %02x\n", canfd->data[0],
		 canfd->data[1], canfd->data[2], canfd->data[3], canfd->data[4], canfd->data[5],
		 canfd->data[6], canfd->data[7]);

	netif_receive_skb(skb);
}

static unsigned int hook_func(void *priv, struct sk_buff *skb, const struct nf_hook_state *state)
{
	struct iphdr *ip_header;
	struct udphdr *udp_header;
	struct osr_canfd_tx can_tx;
	//struct tcphdr *tcp_header;

	ip_header = (struct iphdr *)skb_network_header(skb);

	if (ip_header->protocol == UDP) {
		udp_header = (struct udphdr *)(skb_transport_header(skb));

		if (ntohs(udp_header->source) == GW_PORT) {
			//pr_debug("Received data from port: %u\n", ntohs(udp_header->source));

			if ((ntohs(udp_header->len) - sizeof(struct udphdr))
								!= sizeof(struct osr_canfd_tx)) {
				// check for ack from Gateway
				if (0 == strncmp(skb_transport_header(skb) + sizeof(struct udphdr),
					"gw_ack", ntohs(udp_header->len) - sizeof(struct udphdr))) {

					report_gw_conn();
					return NF_DROP;
				}

				pr_emerg("Packet is incompatible with size of 104 bytes. \
						Dropped\n");
				return NF_DROP;
			}

			// extracting data from skb
			memcpy(&can_tx, skb_transport_header(skb) + sizeof(struct udphdr),
				ntohs(udp_header->len) - sizeof(struct udphdr));
			sender(can_tx.cfd);
		}
	}

	return NF_ACCEPT;
}

static int __init module_init_func(void)
{
	int ret;

	pr_info("Netfilter started\n");
	read_lock(&dev_base_lock);
	gw_net_dev = dev_get_by_name(&init_net, iface_name);

	ret = request_module("dnv_driver");

	if (ret != 0) {
		pr_emerg("Error: Netfilter module has dependency of module dnv_driver\n");
		return ret;
	}

	if (gw_net_dev == NULL) {
		read_unlock(&dev_base_lock);
		pr_emerg("Error: Netfilter received bad module parameter: %s\n", iface_name);
		return -EINVAL;
	}

	pr_info("Netfilter connected to interface %s\n", iface_name);
	can_net_dev = first_net_device(&init_net);

	while (can_net_dev) {
		if (strstr(can_net_dev->name, "can"))
			break;

		can_net_dev = next_net_device(can_net_dev);
	}
	
	if (can_net_dev == NULL) {
		dev_put(gw_net_dev);
		read_unlock(&dev_base_lock);
		pr_emerg("Failed to connect to CAN interface\n");
		return -ENETUNREACH;
	}

	pr_info("Netfilter found CAN interface %s\n", can_net_dev->name);
	net = dev_net(gw_net_dev);
	//can_net_dev->flags |= (IFF_UP | IFF_RUNNING);
	read_unlock(&dev_base_lock);

	h_ops.hook = hook_func;			//function to call when condition fits
	h_ops.pf = PF_INET;			//IPV4 packets
	h_ops.hooknum = NF_IP_PRE_ROUTING;	//called right after packet recieved
	h_ops.priority = NF_IP_PRI_FIRST;	//set to highest priority over all other hooks

        nf_register_net_hook(net, &h_ops);
	return 0;
}

static void __exit module_exit_func(void)
{
	nf_unregister_net_hook(net, &h_ops);
	dev_put(gw_net_dev);
	pr_info("Netfilter stopped\n");
}


module_init(module_init_func);
module_exit(module_exit_func);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Custom netfilter for Denverton");
MODULE_AUTHOR("Sergey Buloshnikov - OSR");

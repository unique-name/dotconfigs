/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: contains implementation of class tcp client.
|
************************************************************************/

#include <exception>
#include <iostream>
#include <tcp_client.hpp>

using boost::asio::ip::tcp;

tcp_client::tcp_client(const char *hostname, const unsigned int &port, boost::asio::io_service &ios)
	: socket_ptr(0),
	  endpoint(boost::asio::ip::address::from_string(hostname), port)
{
	sync_connect(ios);
}

void tcp_client::sync_connect(boost::asio::io_service &ios)
{
	boost::system::error_code error;
	status = DISCONNECTED;

	while (1) {
		if (socket_ptr != 0) {
			socket_ptr->close();
			free(socket_ptr);
		}
	
		socket_ptr = new tcp::socket(ios);
			socket_ptr->connect(endpoint, error);
	
		if (error) {
			sleep(1);
			continue;
		}

		else {
			status = CONNECTED;
			syslog(LOG_NOTICE, "Connected to SYS manager");
			std::cout << "Connected to SYS manager" << std::endl;
			break;
		}
	}
}

void tcp_client::send_msg(const char *msg, size_t size)
{
	// send size of message and then message itself
	boost::asio::write(*socket_ptr, boost::asio::buffer(&size, sizeof(size_t)));
	boost::asio::write(*socket_ptr, boost::asio::buffer(msg, size));
}

char* tcp_client::sync_read(const boost::system::error_code &error)
{
	if (error) {
		status = DISCONNECTED;
		syslog(LOG_NOTICE, "Disconnected from SYS manage");
		std::cout << "Disconnected from SYS manage" << std::endl;
		return 0;
	}

	else {
		size_t size = sizeof(size_t);
		boost::asio::read(*socket_ptr, boost::asio::buffer(data, size));

		if (error) {
			status = DISCONNECTED;
			syslog(LOG_NOTICE, "Disconnected from SYS manage");
			std::cout << "Disconnected from SYS manage" << std::endl;
			return 0;
		}

		size = *data;
		boost::asio::read(*socket_ptr, boost::asio::buffer(data, size));
	}
	
	return data;
}


/************************************************************************
| Copyright (c) OSR Enterprises AG, year.     All rights reserved.
|
| This software is the exclusive and confidential property of
| OSR Enterprises AG and may not be disclosed, reproduced or modified
| without permission from OSR Enterprises AG.
|
| Description: Implementation of tester for json setup file
|
************************************************************************/

#include <cstring>
#include <fstream>
#include <iostream>
#include <json/reader.h>
#include <json/value.h>

Json::Reader reader;
Json::Value json_val;

using std::cout;
using std::endl;

int main(int argc, char *argv[])
{
	auto exit_fail_rutine = [](std::string str) {
		std::cout << endl << "Data parsing failed !!!" << endl;
		cout << "Stage: " << str << endl;
		exit(1);
	};

	std::array<std::string, 2> card_types = {"DaughterBoard", "TopBoard"};
	std::array<std::string, 2> can_baudrates = {"500 Kbps", "1 Mbps"};
	std::array<std::string, 2> cam_host_src = {"Internal", "External"};

	if (argc > 1) {
		std::string filename(argv[1]);
		std::ifstream json_file(filename);

		if (!json_file.is_open()) {
			cout << "Wrong file name or path" << endl;
			exit(1);
		}

		if (false == reader.parse(json_file, json_val, false)) {
			cout << "File parsing failed. Problem in syntax" << endl;
			exit(1);
		}
	}
	else {
		cout << "Please provide file as argument" << endl;
		exit(1);
	}

	Json::Value sub_obj = json_val["Hardware"];
	cout << "General HW data:" << endl;
	cout << "----------------" << endl;

	if (sub_obj["name"].empty())
		exit_fail_rutine("General name parsing");
	else
		cout << "name: " << sub_obj["name"].asString() << endl;

	if (sub_obj["serialNumber"].empty())
		exit_fail_rutine("General serial number parsing");
	else
		cout << "serial num: " << sub_obj["serialNumber"].asString() << endl;

	if (sub_obj["numOfSlots"].empty())
		exit_fail_rutine("General number of slots parsing");
	else
		cout << "parsed num of slots: " << sub_obj["numOfSlots"].asInt() << endl;

	cout << "actual num of slots: " << json_val["BoardsCollection"].size() << endl;

	if ((int)json_val["BoardsCollection"].size() != sub_obj["numOfSlots"].asInt())
		exit_fail_rutine("comparing actual num of slots with parsed");

	if (sub_obj["hwVersion"].empty())
		exit_fail_rutine("General hw version parsing");
	else
		cout << "hw version: " << sub_obj["hwVersion"].asString() << endl;

	if (sub_obj["swVersion"].empty())
		exit_fail_rutine("General sw version parsing");
	else
		cout << "sw version: " << sub_obj["swVersion"].asString() << endl;

	for (int board_num = 0; board_num < (int)json_val["BoardsCollection"].size(); ++board_num) {
		Json::Value sub_obj = json_val["BoardsCollection"][board_num];
		bool is_active = false;

		cout << endl << "-------------------" << endl;
		cout << "Daughter card data:" << endl;

		if (sub_obj["SlotIndex"].empty())
			exit_fail_rutine("Board slot index parsing");
		else
			cout << "slot index: " << sub_obj["SlotIndex"].asInt() << endl;

		if (sub_obj["BoardType"].empty())
			exit_fail_rutine("Board type parsing");
		else {
			cout << "board type: " << sub_obj["BoardType"].asString() << endl;

			bool present = false;

			for (const auto& type : card_types) {
				if (type == sub_obj["BoardType"].asString()) {
					present = true;
					break;
				}
			}

			if (!present)
				exit_fail_rutine("Board type parsing");
		}

		if (sub_obj["HWVersion"].empty())
			exit_fail_rutine("Board hw version parsing");
		else
			cout << "hw version: " << sub_obj["HWVersion"].asString() << endl;

		if (sub_obj["FPGAVersion"].empty())
			exit_fail_rutine("Board fpga version parsing");
		else
			cout << "fpga version: " << sub_obj["FPGAVersion"].asString() << endl;

		for (int port = 0; port < (int)sub_obj["PortsCollection"].size(); ++port) {
			Json::Value port_obj = sub_obj["PortsCollection"][port];
			std::string port_type;

			cout << endl << "Port: ";

			if (port_obj["Index"].empty())
				exit_fail_rutine("Port index parsing");
			else
				cout << "index " << port_obj["Index"].asString() << endl;

			if (port_obj["PortType"].empty())
				exit_fail_rutine("Port type parsing");
			else {
				port_type = port_obj["PortType"].asString();
				cout << "port type: " << port_type << endl;
			}

			if (port_obj["Device"].isNull()) {
				cout << "Port is not active" << endl;
				continue;
			}

			is_active = true;
			Json::Value cust_obj = port_obj["Device"]["FieldsSelections"];

			if (port_type == "FPD") {

				if (cust_obj.empty())
					exit_fail_rutine("Camera fields are empty");

				int size = cust_obj.size();
				int ind;

				for (ind = 0; ind < size; ++ind) {
					if (cust_obj[ind]["FieldName"].asString() == "Resolution") {
						cout << "resolution: " << cust_obj[ind]["Value"]
									.asString() << endl;
						break;
					}
				}

				if (ind == size)
					exit_fail_rutine("Camera resolution parsing");

				for (ind = 0; ind < size; ++ind) {
					if (cust_obj[ind]["FieldName"].asString() == "Host") {
						cout << "host: " << cust_obj[ind]["Value"]
									.asString() << endl;
						break;
					}
				}

				if (ind == size)
					exit_fail_rutine("Camera host source parsing");

				bool present = false;
	
				for (const auto& host : cam_host_src) {
					if (host == cust_obj[ind]["Value"].asString()) {
						present = true;
						break;
					}
				}
	
				if (!present)
					exit_fail_rutine("Camera host source parsing");

				for (ind = 0; ind < size; ++ind) {
					if (cust_obj[ind]["FieldName"].asString() == "Frame Rate") {
						cout << "frame rate: " << cust_obj[ind]["Value"]
									.asInt() << endl;
						break;
					}
				}

				if (ind == size)
					exit_fail_rutine("Camera frame rate parsing");

				for (ind = 0; ind < size; ++ind) {
					if (cust_obj[ind]["FieldName"].asString() == "Format") {
						cout << "format: " << cust_obj[ind]["Value"]
									.asString() << endl;
						break;
					}
				}

				if (ind == size)
					exit_fail_rutine("Camera format parsing");

				for (ind = 0; ind < size; ++ind) {
					if (cust_obj[ind]["FieldName"].asString() == "HFOV") {
						cout << "HFOV: " << cust_obj[ind]["Value"]
										.asInt() << endl;
						break;
					}
				}

				if (ind == size)
					exit_fail_rutine("Camera HFOV parsing");
			}

			else if (port_type == "ETH") {
#if 0
				if (cust_obj[0]["FieldName"].asString() == "Spin Rate")
					cout << "spin rate: " << cust_obj[0]["Value"].asInt()
						<< endl;

				if (cust_obj[3]["FieldName"].asString() == "IP Address")
					cout << "IP address " << cust_obj[3]["Value"].asString()
						<< endl;
#endif
				cout << "Eth data... currently nothing to parse" << endl;
			}

			else if (port_type == "CAN") {
				if (cust_obj[1]["FieldName"].asString() == "Header Bit Rate") {
					cout << "header br: " << cust_obj[1]["Value"].asString()
					     << endl;

					bool present = false;

					for (const auto& baud_str : can_baudrates) {
						if (baud_str == cust_obj[1]["Value"].asString()) {
							present = true;
							break;
						}
					}

					if (!present)
						exit_fail_rutine("CAN header br parsing");
				}

				else
					exit_fail_rutine("CAN header br parsing");

				if (cust_obj[2]["FieldName"].asString() == "Data Bit Rate") {
					cout << "data br: " << cust_obj[2]["Value"].asString()
					     << endl;

					bool present = false;

					for (const auto& baud_str : can_baudrates) {
						if (baud_str == cust_obj[2]["Value"].asString()) {
							present = true;
							break;
						}
					}

					if (!present)
						exit_fail_rutine("CAN header br parsing");
				}

				else
					exit_fail_rutine("CAN data br parsing");
			}

			else if (port_type == "USB") {
				cout << "USB data... currently nothing to parse" << endl;
			}

			else
				exit_fail_rutine("Can not recognize port type");
		}

		if (false == is_active)
			cout << endl << "Warning: Board does not have active ports !!!" << endl;
	}

	cout << endl << "----------------" << endl;
	cout << "End of parsing" << endl;
	return 0;
}
